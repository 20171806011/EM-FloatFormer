#!/usr/bin/env python3
"""P3-A independent audit of frozen run records, checkpoint hashes and replay.
Does not train, tune, or change any model; civilian passive synthetic task only.
"""
import csv
import hashlib
import json
import math
import statistics
from pathlib import Path
import torch
from ofdm_baseline import make_batch
from p3_a import (MODEL_NAMES,NAMES,N,PROFILES,SNRS,SEEDS,verify,load_models,sha256)
from p3_models import EquivDelayConv


def audit(path=Path('p3a_results'), checkpoint=Path('p3a_checkpoints'), frames=768):
    torch.set_num_threads(4)
    train=list(csv.DictReader((path/'training_registry.csv').open()))
    assert len(train)==len(SEEDS)*len(MODEL_NAMES),len(train)
    checked_shas={}
    for x in train:
        seed=int(x['seed']);name=x['model']
        assert seed in SEEDS and name in MODEL_NAMES and int(x['steps'])==600
        file=checkpoint/f'model_{name}_seed{seed}.pt'
        assert file.exists()
        digest=sha256(file)
        assert digest==x['sha256'],file
        checked_shas[file.name]=digest
    source_shas={n:sha256(Path(n)) for n in
          ('p3_models.py','p3_a.py','test_p3_0_a.py','p3_a_audit.py')}
    rows=list(csv.DictReader((path/'ber_by_seed.csv').open()))
    expected=len(SEEDS)*len(PROFILES)*len(SNRS)*len(NAMES)
    assert len(rows)==expected,(len(rows),expected)
    seen=set()
    for r in rows:
        seed=int(r['seed']);snr=int(r['snr_db']);p=r['profile'];name=r['method']
        assert seed in SEEDS and snr in SNRS and p in PROFILES and name in NAMES
        key=(seed,p,snr,name);assert key not in seen;seen.add(key)
        assert int(r['bits'])==frames*N*2
        assert 0<=int(r['errors'])<=int(r['bits'])
        assert abs(float(r['ber'])-int(r['errors'])/int(r['bits']))<1e-12
        assert math.isfinite(float(r['channel_mse'])) and float(r['channel_mse'])>=0
    sums=list(csv.DictReader((path/'ber_summary.csv').open()))
    assert len(sums)==len(PROFILES)*len(SNRS)*len(NAMES)
    for summary in sums:
        selected=[r for r in rows if r['profile']==summary['profile']
                  and r['snr_db']==summary['snr_db'] and r['method']==summary['method']]
        assert len(selected)==len(SEEDS)
        errors=sum(int(r['errors']) for r in selected)
        bits=sum(int(r['bits']) for r in selected)
        assert int(summary['errors'])==errors
        assert int(summary['bits'])==bits
        assert abs(float(summary['pooled_ber'])-errors/bits)<1e-12
    replay_total=0
    for seed in SEEDS:
        replay_total+=verify(checkpoint,path,seed,frames,600,64)
    assert replay_total==len(SEEDS)*4*len(NAMES)
    phase_rows=[]
    for seed in SEEDS:
        models=load_models(seed,checkpoint)
        torch.manual_seed(4110000+seed)
        b=make_batch(256,N,10,10,'cpu',PROFILES['long12'])
        for name,m in models.items():
            with torch.inference_mode():
                h=m.channel(b.yp,b.yd,b.noise_var)
                pred=m(b.yp,b.yd,b.noise_var)
                for phi in (.15,1.2,2.4):
                    rot=complex(math.cos(phi),math.sin(phi))
                    hr=m.channel(b.yp*rot,b.yd*rot,b.noise_var)
                    pr=m(b.yp*rot,b.yd*rot,b.noise_var)
                    hdiff=float((hr-h*rot).abs().max())
                    diff=float((pr-pred).abs().max())
                    flips=int(((pred>0)!=(pr>0)).sum())
                    assert hdiff<1e-5,(name,seed,hdiff)
                    assert diff<1e-5,(name,seed,diff)
                    assert flips==0
                    phase_rows.append(dict(seed=seed,model=name,angle_rad=phi,
                        max_channel_equiv_abs_error=hdiff,max_logits_abs_error=diff,
                        changed_hard_bits=flips))
    # Profiles and test RNG family are disjoint from new training RNG seeds.
    data_seeds={int(x['test_seed']) for x in rows}
    assert len(data_seeds)==len(SEEDS)*len(PROFILES)*len(SNRS)
    assert min(data_seeds)>200000000
    # The object-level noise-only threshold expectation is independently tested
    # by test_p3_0_a.py; this stage checks resulting checkpoint behavior.
    from p3_a import write_csv
    write_csv(path/'trained_phase_audit.csv',phase_rows)
    result=dict(status='PASS',protocol='P3_0_A_PROTOCOL.md — GitHub committed before training',
        seed_count=len(SEEDS),train_checkpoints=len(train),train_sha256=checked_shas,
        code_sha256=source_shas,rows_raw=len(rows),rows_aggregate=len(sums),
        bits_per_model_profile_snr=len(SEEDS)*frames*N*2,
        exact_replay_cells=replay_total,phase_audit_rows=len(phase_rows),
        max_phase_channel_error=max(x['max_channel_equiv_abs_error'] for x in phase_rows),
        max_phase_logit_error=max(x['max_logits_abs_error'] for x in phase_rows),
        changed_decisions=sum(x['changed_hard_bits'] for x in phase_rows),
        limitation='same Python/PyTorch CPU and simulator; not independent codebase/SDR replication')
    (path/'independent_audit.json').write_text(json.dumps(result,indent=2))
    return result

if __name__=='__main__':
    r=audit()
    print('P3-A AUDIT',r['status'],'replay',r['exact_replay_cells'],
          'phase rows',r['phase_audit_rows'],'max phase error',r['max_phase_channel_error'])
