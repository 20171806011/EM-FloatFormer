#!/usr/bin/env python3
"""Independent algebraic / structural checks for P3-A (no training needed)."""
import math
import unittest
import torch
from ofdm_baseline import make_batch, covariance_matrix, estimate_channel
from p3_models import EquivDelayConv,model_factory_p3
from p3_a import dft_threshold, PROFILES,N


def run_tests():
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(P3AuditTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():raise RuntimeError('P3-0 tests failed')


class P3AuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):torch.set_num_threads(4)

    def test_frozen_architecture_size(self):
        m=EquivDelayConv()
        self.assertLess(sum(p.numel() for p in m.parameters()),3000)

    def test_fft_convolution_identity_and_9tap_limit(self):
        n=N
        mask=torch.zeros(n,dtype=torch.float64);mask[:8]=1
        k=torch.fft.fft(mask.to(torch.complex128))/n
        torch.manual_seed(8)
        z=torch.complex(torch.randn(7,n,dtype=torch.float64),torch.randn(7,n,dtype=torch.float64))
        # Exact desired delay response, versus equivalent frequency circular convolution.
        lhs=torch.fft.fft(torch.fft.ifft(z,dim=-1)*mask,dim=-1)
        rhs=torch.fft.ifft(torch.fft.fft(z,dim=-1)*torch.fft.fft(k,dim=-1),dim=-1)
        self.assertLess((lhs-rhs).abs().max().item(),1e-12)
        allowed=torch.zeros(n,dtype=torch.bool)
        allowed[torch.tensor([28,29,30,31,0,1,2,3,4])]=True
        rel=((k[~allowed].abs().square().sum())/(k.abs().square().sum())).sqrt().item()
        self.assertAlmostEqual(rel,0.3029641990831974,places=11)
        self.assertEqual(int((k.abs()>1e-12).sum()),25)

    def test_exact_common_phase_equivariance_model(self):
        torch.manual_seed(48)
        b=make_batch(40,N,10,10,'cpu',PROFILES['long6'])
        m=EquivDelayConv().eval()
        with torch.inference_mode():
            ref=m.channel(b.yp,b.yd,b.noise_var)
            logits=m(b.yp,b.yd,b.noise_var)
            for phi in (0.1,1.3,2.5):
                z=complex(math.cos(phi),math.sin(phi))
                shifted=m.channel(b.yp*z,b.yd*z,b.noise_var)
                self.assertLess((shifted-ref*z).abs().max().item(),5e-6)
                lr=m(b.yp*z,b.yd*z,b.noise_var)
                self.assertLess((lr-logits).abs().max().item(),5e-6)
                self.assertEqual(int(((lr>0)!=(logits>0)).sum().item()),0)

    def test_no_data_used_to_estimate_channel(self):
        torch.manual_seed(87)
        b=make_batch(5,N,10,10,'cpu')
        model=EquivDelayConv().eval()
        with torch.inference_mode():
            h=model.channel(b.yp,b.yd,b.noise_var)
            a=model.channel(b.yp,torch.randn_like(b.yd),b.noise_var)
        self.assertTrue(torch.equal(h,a))

    def test_finite_logits_and_gradients(self):
        torch.manual_seed(99)
        b=make_batch(16,N,0,20,'cpu',PROFILES['train3'])
        for name in ('p3_equiv_delay','res_unfold','res_equiv_local'):
            model=model_factory_p3(name)
            logits=model(b.yp,b.yd,b.noise_var)
            self.assertTrue(torch.isfinite(logits).all(),name)
            loss=torch.nn.functional.binary_cross_entropy_with_logits(logits,b.bits.float())
            loss.backward()
            self.assertTrue(all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None),name)

    def test_classical_threshold_consistency_and_finite(self):
        torch.manual_seed(24)
        b=make_batch(32,N,10,10,'cpu',PROFILES['long12'])
        for mode in ('hard','soft'):
            h=dft_threshold(b.yp,b.noise_var,mode)
            self.assertTrue(torch.isfinite(h).all())
            t=torch.fft.ifft(b.yp,dim=-1)
            nt=b.noise_var/N
            T=(nt*math.log(N/.05)).sqrt()
            if mode=='hard':a=(t.abs()>T).float()
            else:a=(1-T/(t.abs()+1e-12)).clamp(min=0)
            independent=torch.fft.fft(t*a,dim=-1)
            self.assertLess((independent-h).abs().max().item(),1e-8)

    def test_noise_floor_false_crossings(self):
        torch.manual_seed(751)
        num=12000
        nv=.1
        z=(torch.randn(num,N)+1j*torch.randn(num,N))*math.sqrt(nv/2)
        delayed=torch.fft.ifft(z,dim=-1)
        T=math.sqrt((nv/N)*math.log(N/.05))
        empirical=float((delayed.abs()>T).float().sum(dim=-1).mean())
        self.assertLess(abs(empirical-.05),.012)

    def test_lmmse_independent_delay_wiener(self):
        torch.manual_seed(651)
        b=make_batch(12,N,10,10,'cpu',PROFILES['long6'])
        cov=covariance_matrix(N,PROFILES['long6'],'cpu')
        h0=estimate_channel(b.yp,b.noise_var,'lmmse',covariance=cov)
        import torch.nn.functional as F
        p=torch.tensor(PROFILES['long6'],dtype=torch.float32);p=p/p.sum()
        g=p[None,:]/(p[None,:]+b.noise_var/N)
        ht=torch.fft.ifft(b.yp,dim=-1)[...,:len(p)]*g
        h1=torch.fft.fft(F.pad(ht,(0,N-len(p))),dim=-1)
        self.assertLess((h0-h1).abs().max().item(),5e-5)

    def test_unseen_support_profiles(self):
        self.assertEqual(len(PROFILES['long12']),12)
        self.assertEqual(len(PROFILES['sparse12']),12)
        self.assertTrue(any(v==0 for v in PROFILES['sparse12']))
        self.assertGreater(PROFILES['sparse12'][-1],0)
        for p in PROFILES.values():self.assertGreater(sum(p),0)

if __name__=='__main__':run_tests()
