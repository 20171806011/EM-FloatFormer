#!/usr/bin/env python3
"""Generate P3-0/P3-A report directly from original measured CSV and audit JSON."""
import csv,statistics,json,math,hashlib
from pathlib import Path
from p3_a import MODEL_NAMES,PROFILES,SEEDS,SNRS

root=Path(__file__).resolve().parent
raw=list(csv.DictReader((root/'p3a_results/ber_by_seed.csv').open()))
summary=list(csv.DictReader((root/'p3a_results/ber_summary.csv').open()))
latency=list(csv.DictReader((root/'p3a_results/latency_cpu.csv').open()))
audit=json.loads((root/'p3a_results/independent_audit.json').read_text())
assert audit['status']=='PASS' and audit['exact_replay_cells']==220

def key(p,method,snr=10):
    a=[x for x in summary if x['profile']==p and x['method']==method and int(x['snr_db'])==snr]
    assert len(a)==1
    return float(a[0]['pooled_ber'])*100

def info(p,m,snr=10):
    a=[x for x in summary if x['profile']==p and x['method']==m and int(x['snr_db'])==snr]
    assert len(a)==1
    return float(a[0]['avg_channel_mse'])

names=['p3_equiv_delay','res_unfold','res_equiv_local','ls','dft8','dft12','dft_thresh_hard','dft_thresh_soft','lmmse_train3','lmmse_matched_privileged']
labels={'p3_equiv_delay':'P3 new equivariant delay CNN (985 params)',
        'res_unfold':'P2 delay unfolded (722 params)',
        'res_equiv_local':'P2 equivariant frequency FIR (2,060 params)',
        'ls':'LS','dft8':'DFT-8 (assumes delay <= 7)',
        'dft12':'DFT-12 (known extended support)',
        'dft_thresh_hard':'DFT-threshold hard (no support prior)',
        'dft_thresh_soft':'DFT-threshold soft (no support prior)',
        'lmmse_train3':'LMMSE train3 population covariance',
        'lmmse_matched_privileged':'LMMSE correct test covariance (privileged)'}

lines=[]
def put(*s):lines.extend(s)
put('# EM-FloatFormer P3-0 / P3-A — mathematical audit and delay-domain model evaluation',
    '', '**2026-11-15 · Completed · exploratory · synthetic receive-only civilian QPSK/OFDM only.**',
    '', '## Protocol and frozen scope',
    '', '- Frozen on GitHub before P3-A training: [`P3_0_A_PROTOCOL.md`](P3_0_A_PROTOCOL.md), commit `bce622eddc0d8277c64073033c1248eb035a3803`. This code/data report was generated *after* the frozen protocol; no later training-budget changes or new test conditions were introduced.',
    '- Model code: `p3_models.py`; training/evaluation: `p3_a.py`; independent tests: `test_p3_0_a.py` and `p3_a_audit.py`. The archived P2-E confirmatory results are unchanged. P3-B/C/D/E have **not** been started.',
    '- Five *new* training seeds 46001–46005, 600 AdamW steps per model, batch64, train3 only, 0–20 dB randomly sampled SNR; all three neural model families receive identical training frames per seed. Exactly 15 newly trained checkpoints. Decoder supervision is QPSK BCE, **not** channel MSE.',
    '- Five profiles × 0/10/20dB, 768 held-out frames per seed × 64 bits/frame => **245,760 bits per receiver per scenario**, same simulated frames across estimators; 5 seeds are the statistical replication units, **not** the 245,760 bits.',
    '- All tests remain 32-tone full-pilot, one static pilot/data pair, AWGN, ideal synchronization, no coding, no genuine ADC or RF hardware. All results exploratory, no confirmatory superiority or preregistered p-value claims.',
    '', '## P3-0 mathematical result and reproducibility',
    '', 'Let `D=diag(1,...,1,0,...,0)` be the length-32 first-eight-delay mask. The physical DFT-8 estimator is `FFT(D*IFFT(Ypilot))`. By the discrete convolution theorem this is circular convolution of the 32-tone pilot observation with a frequency-domain kernel `k=FFT(diag(D))/32`. The exact kernel has **25 nonzero coefficients**. Its nearest kernel whose lag support is restricted to `{-4,-3,-2,-1,0,1,2,3,4}` has relative coefficient L2 error **0.3029641990831974**. The independent double-precision circular convolution identity passed to `1e-12` numerical tolerance.',
    '', '**Important scope:** this is a restriction of the **fixed linear nine-tap convolution component**, not a lower bound on the entire `res_equiv_local` network because that network includes nonlinear input-dependent invariant gates. The older `res_unfold` already contained an IFFT/real shrinkage/FFT path; P3-A is not the first attempt at a delay-domain learned representation.',
    '', 'The P3 model performs `t=IFFT(Ypilot)` and `Hhat=FFT[t * sigmoid(g_theta(invariants))]`, where the real gate is computed by two circular 1-D convolutions of invariant amplitude/noise/delay-index features. For any `u=exp(i phi)`, the gate is unchanged by multiplying `Ypilot` by `u`, hence `Hhat(uYpilot)=uHhat(Ypilot)`. The QPSK equalized output is invariant when both pilot and data are rotated by `u`; this is **common rotation** equivariance, not data-only CFO/CPE invariance.',
    '', 'Pre-training audit: 9/9 math/architecture tests passed, including finite gradients, delay-domain cross-check and theoretical false-threshold crossing test. Trained checkpoint phase-audit: **45/45 cases** (5 seeds × 3 learned models × 3 angles) with zero changed hard bits. Maximum channel equivariance error: `{:.3g}`; maximum logit difference `{:.3g}` (floating-point).'.format(audit['max_phase_channel_error'],audit['max_phase_logit_error']),
    '', '## BER results at 10 dB', '',
    'Values are **BER % (lower is better)**, pooled across five new seeds on 245,760 bits per receiver/profile. Correct-test LMMSE has unavailable privileged profile statistics. DFT-8 support assumption is valid only through delay 7; DFT-12 knows maximum support12. Threshold methods use only the reported noise variance and a prespecified noise-only false-crossings rate 0.05; no profile-specific tuning.',
    '', '| Method | train3 | equal4 | long6 | long12 | sparse12 |','|---|---:|---:|---:|---:|---:|')
for name in names:
    put('| {} | {} |'.format(labels[name], ' | '.join(f'{key(p,name):.3f}%' for p in PROFILES)))
put('', '## Prespecified exploratory contrasts', '',
    'We report new-minus-comparator differences in **BER percentage points**. Negative means the P3 model is better. Both long6 and long12 are evaluated at 10dB without any selection of checkpoint or baseline after observing the test.',
    '', '| Profile | Comparator | Mean new − comparator (pp) | Five paired-seed differences (pp) |',
    '|---|---|---:|---|')
by={(int(x['seed']),x['profile'],int(x['snr_db']),x['method']):float(x['ber']) for x in raw}
for p in ('long6','long12'):
    for comp in ('res_unfold','res_equiv_local','dft8','dft_thresh_hard','dft_thresh_soft'):
        diffs=[100*(by[(s,p,10,'p3_equiv_delay')]-by[(s,p,10,comp)]) for s in SEEDS]
        put(f'| {p} | {comp} | {statistics.mean(diffs):+.3f} | '+', '.join(f'{v:+.3f}' for v in diffs)+' |')
put('', 'Despite consistent directional differences on some comparisons, n=5 is an exploratory sample. No multiple-comparison-confirmatory inference is made. No hyperparameter changes followed the tests.',
    '', '## Additional 0/20-dB stress results', '',
    '| Profile | SNR | P3 delay | P2 delay | DFT-8 | DFT-threshold hard | DFT-12 |',
    '|---|---:|---:|---:|---:|---:|---:|')
for p in PROFILES:
    for snr in (0,20):
        put('| {} | {} | {} |'.format(p,snr,' | '.join(f'{key(p,m,snr):.3f}%' for m in ('p3_equiv_delay','res_unfold','dft8','dft_thresh_hard','dft12'))))
put('', '## Channel MSE is NOT the same objective as BER', '',
    'At train3/10dB the P3 model BER is {:.3f}%, but its **channel MSE is {:.5f}**, compared with **{:.5f}** for the hard-threshold DFT. The P3 model is trained to classify bits, and shrinking pilot-based channel amplitudes can preserve approximate phase/bit decisions while changing channel amplitudes substantially. A low BER is **not** evidence for high-fidelity complex channel reconstruction.'.format(key('train3','p3_equiv_delay'),info('train3','p3_equiv_delay'),info('train3','dft_thresh_hard')),
    '', 'To inspect the failure mode without retraining, one stored model (seed46001) was evaluated with a diagnostic output-hook at 10dB: mean shrinkage gate over early delays0–2 ≈0.410; delays8–11 ≈0.002; beyond12 ≈0.005 in train3. This is a *descriptive single-seed diagnostic* and explains why the model can suppress delayed paths it did not encounter during training. It is not a causal proof or an average across seeds.',
    '', '## CPU inference measurements (single environment)', '',
    '| Method | Batch1 median (ms) | Batch1 p95 (ms) | Batch64 median (ms) | Params |',
    '|---|---:|---:|---:|---:|')
for name in ('p3_equiv_delay','res_unfold','res_equiv_local','ls','dft8','dft_thresh_hard','dft_thresh_soft'):
    rows=[x for x in latency if x['method']==name]
    a=next(x for x in rows if int(x['batch_frames'])==1)
    b=next(x for x in rows if int(x['batch_frames'])==64)
    put('| {} | {:.4f} | {:.4f} | {:.4f} | {} |'.format(name,float(a['median_ms']),float(a['p95_ms']),float(b['median_ms']),a['params']))
put('', 'These are **PyTorch CPU receiver-forward** times, excluding SDR hardware, protocol framing and real-time RF sample handling. Parameters or latency alone are not proof of production efficiency.',
    '', '## Integrity audit', '',
    '- 15/15 new checkpoints checksum-verified. 825/825 raw per-seed method × condition cells reconciled with 165 aggregate BER rows; **220/220 integer (errors,bits) pairs** independently recomputed from saved checkpoints without retraining. All original counts and profiles saved in `p3a_results/`.',
    '- 45 trained-model U(1) phase checks across all 5 seeds passed with zero hard-decision changes. The `test_p3_0_a.py` unit suite passed 9/9 cases.',
    '- Training RNG family and held-out evaluation family are disjoint. All receivers evaluated the same simulated frames within each scenario. `p3a_results/independent_audit.json` contains SHA256 of new model files and checkpoints.',
    '- Both conventional threshold variants preserve the frozen threshold `T=sqrt(noise_var/32 * ln(32/0.05))`. Under noise alone the threshold-crossing test agrees with its theoretical expected 0.05 false crossings/frame.',
    '', '## Interpretation and stopping point', '',
    '**P3-A partially supports a narrower hypothesis:** better delay representation can improve BER over the two newly retrained P2 neural models on train3/equal4/long6, but it still fails to beat DFT-8 and the adaptive classical threshold baseline on long6. It can degrade sharply on unseen long12 and sparse12; the matched LMMSE reference uses extra privileged test distribution information. A model which performs well on the training family does not automatically possess general structural delay invariance.',
    '', '**P3-A is complete as an exploratory experiment, not a general communications breakthrough.** No P3-B/C/D/E experiment was started. Next hypotheses would require a separately frozen protocol and new data; do not retrofit new training distributions to these frozen comparisons.',
    '', '## Reproduction', '', '```bash',
    'python -m pip install -r requirements.txt',
    'python -m unittest test_p3_0_a -v',
    'python p3_a.py --mode train --seeds 46001 46002 46003 46004 46005 --steps 600 --batch 64 --ckpt p3a_checkpoints --out p3a_results',
    'python p3_a.py --mode eval --seeds 46001 46002 46003 46004 46005 --steps 600 --batch 64 --frames 768 --ckpt p3a_checkpoints --out p3a_results',
    'python p3_a.py --mode verify --seed 46001 --frames 768 --ckpt p3a_checkpoints --out p3a_results',
    'python p3_a_audit.py',
    'python p3_a_make_report.py',
    '```', '',
    'Saved checkpoint binaries are excluded from public GitHub; they are included in the separate full archive. The published source, raw error counts, settings and checksums permit re-training. This is a **same-implementation**, not independent-codebase/hardware, replication.', '')
output=root/'P3_0_A_REPORT.md'
output.write_text('\n'.join(lines),encoding='utf-8')
print('WROTE',output,'bytes',output.stat().st_size)
