#!/usr/bin/env python3
"""P3-0 & P3-A: reproducible simulated civil OFDM receiver comparison.

Adheres to P3_0_A_PROTOCOL.md frozen BEFORE training. No active RF controls.
"""
import argparse
import csv
import hashlib
import json
import math
import os
import platform
import statistics
import time
from collections import defaultdict
from pathlib import Path

import torch
from torch.nn import functional as F
from ofdm_baseline import make_batch, covariance_matrix, estimate_channel, decisions_from_channel
from p3_models import model_factory_p3

N = 32
MODEL_NAMES = ('p3_equiv_delay','res_unfold','res_equiv_local')
TRAIN = (.72,.20,.08)
LONG12 = (.35,.15,.10,.08,.07,.06,.05,.04,.03,.025,.025,.02)
SPARSE12 = (.52,0,0,0,.30,0,0,0,0,0,0,.18)
PROFILES = {'train3': TRAIN, 'equal4':(.25,)*4,
            'long6':(.40,.22,.15,.10,.08,.05),
            'long12':LONG12,'sparse12':SPARSE12}
SNRS = (0,10,20)
SEEDS = (46001,46002,46003,46004,46005)
BASELINES = ('ls','dft8','dft12','dft_thresh_hard','dft_thresh_soft',
             'lmmse_train3','lmmse_matched_privileged','true_channel_inaccessible')
NAMES = MODEL_NAMES + BASELINES
PROTOCOL_URL = 'https://github.com/20171806011/EM-FloatFormer/blob/main/P3_0_A_PROTOCOL.md'


def dft_threshold(yp, nv, mode='hard', false_crossings=.05):
    """Fixed familywise false-crossings threshold under Gaussian pilot noise.

    Under noise-only taps, abs(t)**2 / (noise_var/N) has exponential tail.
    E[no. noise-only crossings] = 32*exp(-T**2/(nv/32))=0.05.
    """
    if mode not in ('hard','soft'):
        raise ValueError(mode)
    t = torch.fft.ifft(yp, dim=-1)
    threshold = torch.sqrt((nv / yp.shape[-1]) * math.log(yp.shape[-1]/false_crossings))
    a = t.abs()
    if mode == 'hard':
        gain = (a > threshold).to(a.dtype)
    else:
        gain = torch.clamp(1 - threshold/(a + 1e-12), min=0.0)
    return torch.fft.fft(t * gain, dim=-1)


def classical_channels(b, train_cov, test_cov):
    yp, nv = b.yp, b.noise_var
    return {
        'ls':yp,
        'dft8':estimate_channel(yp,nv,'dft',taps=8),
        'dft12':estimate_channel(yp,nv,'dft',taps=12),
        'dft_thresh_hard':dft_threshold(yp,nv,'hard'),
        'dft_thresh_soft':dft_threshold(yp,nv,'soft'),
        'lmmse_train3':estimate_channel(yp,nv,'lmmse',covariance=train_cov),
        'lmmse_matched_privileged':estimate_channel(yp,nv,'lmmse',covariance=test_cov),
        'true_channel_inaccessible':b.h,
    }


def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda: f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def model_init(name,seed):
    h=int(hashlib.sha256(name.encode()).hexdigest()[:7],16)
    torch.manual_seed((seed*971+h)%(2**31))
    model=model_factory_p3(name)
    model.train()
    return model


def train(seed,steps,batch_size,dest):
    models={name:model_init(name,seed) for name in MODEL_NAMES}
    opts={k:torch.optim.AdamW(m.parameters(),lr=.002,weight_decay=1e-4)
          for k,m in models.items()}
    rng_seed=73000000+seed
    torch.manual_seed(rng_seed)
    begin=time.perf_counter()
    last={}
    for step in range(1,steps+1):
        b=make_batch(batch_size,N,0,20,'cpu',TRAIN)
        for name,m in models.items():
            opts[name].zero_grad(set_to_none=True)
            logits=m(b.yp,b.yd,b.noise_var)
            loss=F.binary_cross_entropy_with_logits(logits,b.bits.float())
            if not torch.isfinite(loss):raise FloatingPointError((name,seed,step))
            loss.backward()
            grads=[p.grad for p in m.parameters() if p.grad is not None]
            if not all(torch.isfinite(x).all() for x in grads):
                raise FloatingPointError((name,seed,step,'gradient'))
            torch.nn.utils.clip_grad_norm_(m.parameters(),1.)
            opts[name].step()
            last[name]=float(loss.detach())
        if step in (1,steps) or step%200==0:
            print('TRAIN',seed,step,'/',steps,'elapsed',round(time.perf_counter()-begin,1),flush=True)
    records=[]
    dest.mkdir(parents=True,exist_ok=True)
    for name,m in models.items():
        path=dest/f'model_{name}_seed{seed}.pt'
        obj=dict(name=name,seed=seed,steps=steps,batch=batch_size,init_seed='sha256-name',
                 data_seed=rng_seed,training_profile=TRAIN,weights=m.state_dict())
        torch.save(obj,path)
        records.append(dict(seed=seed,model=name,params=sum(p.numel() for p in m.parameters()),
            steps=steps, batch=batch_size, final_training_loss=last[name],
            total_seed_training_sec=round(time.perf_counter()-begin,3),
            checkpoint=str(path),sha256=sha256(path)))
    return records


def load_models(seed,src,steps=600,batch_size=64):
    out={}
    for name in MODEL_NAMES:
        file=src/f'model_{name}_seed{seed}.pt'
        obj=torch.load(file,map_location='cpu',weights_only=True)
        for key,val in [('name',name),('seed',seed),('steps',steps),('batch',batch_size)]:
            if obj[key]!=val:raise ValueError(f'{file}: bad {key}')
        m=model_factory_p3(name)
        m.load_state_dict(obj['weights'],strict=True)
        m.eval()
        out[name]=m
    return out


def test_seed(seed,profile_name,snr_db):
    return 195000000+seed*10000+list(PROFILES).index(profile_name)*100+snr_db


def eval_condition(models,seed,profile_name,snr_db,frames):
    profile=PROFILES[profile_name]
    data_seed=test_seed(seed,profile_name,snr_db)
    torch.manual_seed(data_seed)
    train_cov=covariance_matrix(N,TRAIN,'cpu')
    test_cov=covariance_matrix(N,profile,'cpu')
    err={name:0 for name in NAMES}
    sums={name:0.0 for name in NAMES}
    bits=0
    for off in range(0,frames,128):
        with torch.inference_mode():
            b=make_batch(min(128,frames-off),N,snr_db,snr_db,'cpu',profile)
            chans=classical_channels(b,train_cov,test_cov)
            for name,m in models.items():
                # Same signals to all methods; no ground-truth H in model path.
                chans[name]=m.channel(b.yp,b.yd,b.noise_var)
            for name,h in chans.items():
                preds=decisions_from_channel(b.yd,h,b.noise_var)
                err[name]+=int(torch.count_nonzero(preds!=b.bits).item())
                sums[name]+=float((h-b.h).abs().square().sum().item())
            bits+=b.bits.numel()
    assert bits==frames*N*2
    return [dict(seed=seed,profile=profile_name,snr_db=snr_db,method=name,
                 errors=err[name],bits=bits,ber=err[name]/bits,
                 channel_mse=sums[name]/(frames*N),test_seed=data_seed)
            for name in NAMES]


def summarize(rows):
    groups=defaultdict(list)
    for r in rows:groups[(r['profile'],r['snr_db'],r['method'])].append(r)
    out=[]
    for (p,s,m),rs in sorted(groups.items()):
        errors=sum(int(r['errors']) for r in rs)
        bits=sum(int(r['bits']) for r in rs)
        out.append(dict(profile=p,snr_db=s,method=m,n_seeds=len(rs),
                        errors=errors,bits=bits,pooled_ber=errors/bits,
                        avg_channel_mse=statistics.mean(float(r['channel_mse']) for r in rs),
                        seed_sd_ber=(statistics.stdev(float(r['ber']) for r in rs) if len(rs)>1 else None)))
    return out


def write_csv(path,rows):
    if not rows:return
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]))
        w.writeheader();w.writerows(rows)


def evaluate(ckpt,out,frames,seeds,steps,batch):
    out.mkdir(parents=True,exist_ok=True)
    rows=[]
    for seed in seeds:
        models=load_models(seed,ckpt,steps,batch)
        for prof in PROFILES:
            for snr in SNRS:
                rows.extend(eval_condition(models,seed,prof,snr,frames))
        write_csv(out/'ber_by_seed.csv',rows)
        print('EVAL',seed,'all',len(PROFILES)*len(SNRS),'conditions complete',flush=True)
    write_csv(out/'ber_summary.csv',summarize(rows))
    config=dict(seeds=list(seeds),frames=frames,bits_per_seed_scenario=frames*N*2,
                profiles=PROFILES,snrs=SNRS,models=MODEL_NAMES,methods=NAMES,
                training_steps=steps,batch=batch,torch=torch.__version__,
                python=platform.python_version(),cpu_threads=torch.get_num_threads(),
                protocol=PROTOCOL_URL,disclaimer='exploratory only; no real radio')
    (out/'run_config.json').write_text(json.dumps(config,indent=2))
    return rows


def verify(ckpt,out,seed,frames,steps,batch):
    rows=list(csv.DictReader((out/'ber_by_seed.csv').open()))
    records={(int(x['seed']),x['profile'],int(x['snr_db']),x['method']):(int(x['errors']),int(x['bits'])) for x in rows}
    models=load_models(seed,ckpt,steps,batch)
    checked=0
    for prof,snr in [('train3',10),('long6',10),('long12',10),('sparse12',20)]:
        test=eval_condition(models,seed,prof,snr,frames)
        for r in test:
            expected=records[(seed,prof,snr,r['method'])]
            assert expected==(r['errors'],r['bits']),(r,expected)
            checked+=1
    return checked


def latency(models,repeat=150):
    torch.manual_seed(8893)
    rows=[]
    for bs in (1,64):
        b=make_batch(bs,N,10,10,'cpu',TRAIN)
        for name in MODEL_NAMES+('ls','dft8','dft_thresh_hard','dft_thresh_soft'):
            if name in MODEL_NAMES:
                def work(name=name):return models[name](b.yp,b.yd,b.noise_var)
                params=sum(p.numel() for p in models[name].parameters())
            elif name=='ls':
                def work():return decisions_from_channel(b.yd,b.yp,b.noise_var)
                params=0
            elif name=='dft8':
                def work():return decisions_from_channel(b.yd,estimate_channel(b.yp,b.noise_var,'dft',taps=8),b.noise_var)
                params=0
            elif name=='dft_thresh_hard':
                def work():return decisions_from_channel(b.yd,dft_threshold(b.yp,b.noise_var,'hard'),b.noise_var)
                params=0
            else:
                def work():return decisions_from_channel(b.yd,dft_threshold(b.yp,b.noise_var,'soft'),b.noise_var)
                params=0
            with torch.inference_mode():
                for _ in range(20):work()
                timings=[]
                for _ in range(repeat):
                    start=time.perf_counter_ns();work();timings.append((time.perf_counter_ns()-start)/1e6)
            timings.sort()
            rows.append(dict(batch_frames=bs,method=name,params=params,
                             median_ms=statistics.median(timings),
                             p95_ms=timings[math.ceil(.95*repeat)-1],repetitions=repeat,
                             note='CPU FP32 receiver only; no SDR/simulator/FFT from RF sample clock'))
    return rows


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--mode',choices=['train','eval','verify','smoke'],required=True)
    ap.add_argument('--seeds',nargs='+',type=int,default=list(SEEDS))
    ap.add_argument('--steps',type=int,default=600)
    ap.add_argument('--batch',type=int,default=64)
    ap.add_argument('--frames',type=int,default=768)
    ap.add_argument('--ckpt',default='p3a_checkpoints')
    ap.add_argument('--out',default='p3a_results')
    ap.add_argument('--seed',type=int,default=46001)
    args=ap.parse_args();torch.set_num_threads(4)
    ckpt=Path(args.ckpt);out=Path(args.out)
    if args.mode=='smoke':
        from test_p3_0_a import run_tests
        run_tests()
    elif args.mode=='train':
        ckpt.mkdir(parents=True,exist_ok=True)
        out.mkdir(parents=True,exist_ok=True)
        registry=[]
        if (out/'training_registry.csv').exists():
            registry=list(csv.DictReader((out/'training_registry.csv').open()))
            existing={(int(x['seed']),x['model']) for x in registry}
        else: existing=set()
        for seed in args.seeds:
            if all((seed,m) in existing for m in MODEL_NAMES):
                print('SKIP completed seed',seed);continue
            new=train(seed,args.steps,args.batch,ckpt)
            registry.extend(new);write_csv(out/'training_registry.csv',registry)
    elif args.mode=='eval':
        evaluate(ckpt,out,args.frames,args.seeds,args.steps,args.batch)
        models=load_models(args.seeds[0],ckpt,args.steps,args.batch)
        write_csv(out/'latency_cpu.csv',latency(models))
    else:
        print('REPLAY MATCHES',verify(ckpt,out,args.seed,args.frames,args.steps,args.batch),'integer error+bit-count cells')

if __name__=='__main__':main()
