"""Adversarial stress-test probe for p4/classical_baselines.py.

Conducted by Challenger 2 for Milestone 1.
"""

from __future__ import annotations

import math
import sys
import os
import torch
import torch.nn.functional as F
import numpy as np

# Ensure working directory is in sys.path
sys.path.insert(0, os.path.abspath("."))

from p4.simulator import (
    DEFAULT_N,
    DEFAULT_CP,
    DEFAULT_OVERSAMPLE,
    SIGMA_16QAM,
    THRESH_16QAM,
    PROFILES,
    DynamicChannelSimulator,
    apply_rapp_pa_samples,
    generate_frame,
    q16,
    hard_bits_16qam,
)
from p4.classical_baselines import (
    bussgang_lmmse,
    bussgang_params,
    calibrated_16qam_llrs,
    delay_est_dft,
    hard_slice_16qam,
    soft_slice_16qam,
    iterative_dd_pa_cancellation,
)


def run_experiment_1_lmmse_numerical():
    print("=" * 80)
    print("EXPERIMENT 1: Bussgang Decomposition & LMMSE Equalizer Numerical Robustness")
    print("=" * 80)

    # 1A: Extreme SNR regimes
    print("\n--- 1A: Extreme SNR Regimes ---")
    snrs = [-10.0, -5.0, 0.0, 10.0, 20.0, 30.0, 50.0]
    for snr in snrs:
        frame = generate_frame(
            batch_size=200,
            snr_db=snr,
            pa_condition="strong",
            A=1.25,
            generator=torch.Generator().manual_seed(42),
        )
        res = bussgang_lmmse(frame.yp, frame.yd, frame.noise_var, A=1.25)
        
        has_nan = torch.isnan(res.llrs).any().item() or torch.isnan(res.z_hat).any().item()
        has_inf = torch.isinf(res.llrs).any().item() or torch.isinf(res.z_hat).any().item()
        mu_min = res.mu.min().item()
        mu_max = res.mu.max().item()
        sigma2_min = res.sigma2_eff.min().item()
        sigma2_max = res.sigma2_eff.max().item()
        ber = (res.hard_bits != frame.bits).float().mean().item()
        
        print(f"SNR {snr:5.1f} dB | NaN: {has_nan} | Inf: {has_inf} | "
              f"mu: [{mu_min:.2e}, {mu_max:.4f}] | "
              f"sigma2_eff: [{sigma2_min:.2e}, {sigma2_max:.2e}] | BER: {ber:.4f}")
        assert not has_nan and not has_inf, f"NaN or Inf encountered at SNR {snr} dB!"
        assert mu_min >= 1e-8 and mu_max <= 1.0, f"mu bounds violated at SNR {snr} dB!"
        assert sigma2_min >= 0.0, f"Negative variance encountered at SNR {snr} dB!"

    # Test noise_var = 0 (infinite SNR limit)
    print("\n--- 1A-bis: Noise-Free Limit (noise_var = 0) ---")
    frame_zero_noise = generate_frame(
        batch_size=50,
        snr_db=100.0,
        pa_condition="mild",
        A=2.25,
        generator=torch.Generator().manual_seed(42),
    )
    res_zero = bussgang_lmmse(frame_zero_noise.yp, frame_zero_noise.yd, torch.zeros_like(frame_zero_noise.noise_var), A=2.25)
    has_nan_zero = torch.isnan(res_zero.llrs).any().item()
    has_inf_zero = torch.isinf(res_zero.llrs).any().item()
    print(f"Noise=0 limit | NaN: {has_nan_zero} | Inf: {has_inf_zero} | "
          f"mu range: [{res_zero.mu.min().item():.4f}, {res_zero.mu.max().item():.4f}] | "
          f"sigma2 range: [{res_zero.sigma2_eff.min().item():.2e}, {res_zero.sigma2_eff.max().item():.2e}]")
    assert not has_nan_zero and not has_inf_zero, "NaN or Inf at zero noise!"

    # 1B: Singular & Deep Fading Channel States
    print("\n--- 1B: Singular & Deep Fading Channel States ---")
    B, N = 100, 32
    # Scenario 1: Exact Zero Channel (H = 0)
    h_zero = torch.zeros(B, N, dtype=torch.complex64)
    yp_zero = torch.zeros(B, N, dtype=torch.complex64)
    yd_noise = (torch.randn(B, N) + 1j * torch.randn(B, N)) * math.sqrt(0.01)
    nv = torch.full((B, 1), 0.01)
    
    res_hzero = bussgang_lmmse(yp_zero, yd_noise, nv, A=1.25, h_true=h_zero)
    print(f"Exact H=0 | NaN: {torch.isnan(res_hzero.llrs).any().item()} | "
          f"Inf: {torch.isinf(res_hzero.llrs).any().item()} | "
          f"z_hat max: {res_hzero.z_hat.abs().max().item():.2e} | "
          f"mu min/max: {res_hzero.mu.min().item():.2e}/{res_hzero.mu.max().item():.2e} | "
          f"llrs max: {res_hzero.llrs.abs().max().item():.2e}")
    assert not torch.isnan(res_hzero.llrs).any(), "NaN on H=0!"
    assert not torch.isinf(res_hzero.llrs).any(), "Inf on H=0!"
    assert res_hzero.z_hat.abs().max().item() == 0.0, "z_hat must be exactly 0 on H=0!"
    # On zero channel, LLRs should be 0.0 (maximum entropy, 50% bit probability)
    assert res_hzero.llrs.abs().max().item() < 1e-4, "LLR should be 0 on zero channel!"

    # Scenario 2: Deep notch on subcarrier 15 (near-singular H = 1e-12)
    h_notch = (torch.randn(B, N) + 1j * torch.randn(B, N)) / math.sqrt(2.0)
    h_notch[:, 15] = 1e-12 * (torch.randn(B) + 1j * torch.randn(B))
    yd_notch = (torch.randn(B, N) + 1j * torch.randn(B, N))
    res_notch = bussgang_lmmse(h_notch, yd_notch, nv, A=1.25, h_true=h_notch)
    print(f"Deep Notch H=1e-12 | NaN: {torch.isnan(res_notch.llrs).any().item()} | "
          f"Inf: {torch.isinf(res_notch.llrs).any().item()} | "
          f"subcarrier 15 mu: {res_notch.mu[:, 15].mean().item():.2e} | "
          f"subcarrier 15 sigma2: {res_notch.sigma2_eff[:, 15].mean().item():.2e} | "
          f"subcarrier 15 LLR max: {res_notch.llrs[:, 15].abs().max().item():.2e}")
    assert not torch.isnan(res_notch.llrs).any(), "NaN on deep notch!"
    assert not torch.isinf(res_notch.llrs).any(), "Inf on deep notch!"

    # Scenario 3: Massive Gain (H = 1e6)
    h_huge = torch.full((B, N), 1e6, dtype=torch.complex64)
    yd_huge = h_huge * (1.0 + 1.0j)
    res_huge = bussgang_lmmse(h_huge, yd_huge, nv, A=1.25, h_true=h_huge)
    print(f"Massive Gain H=1e6 | NaN: {torch.isnan(res_huge.llrs).any().item()} | "
          f"Inf: {torch.isinf(res_huge.llrs).any().item()} | "
          f"mu mean: {res_huge.mu.mean().item():.4f} | "
          f"sigma2 mean: {res_huge.sigma2_eff.mean().item():.2e}")
    assert not torch.isnan(res_huge.llrs).any(), "NaN on massive gain!"
    assert not torch.isinf(res_huge.llrs).any(), "Inf on massive gain!"

    # 1C: Bussgang parameters across clipping thresholds
    print("\n--- 1C: Bussgang Decomposition Across Clipping Thresholds ---")
    A_vals = [0.2, 0.5, 0.8, 1.0, 1.25, 1.5, 2.0, 2.25, 3.0, 5.0, 10.0, float("inf")]
    for a in A_vals:
        gamma, sigma_d2, p_out = bussgang_params(A=a, alpha=0.5, beta=1.0)
        p_recon = abs(gamma)**2 + sigma_d2
        disc = abs(p_out - p_recon)
        print(f"A={str(a):5s} | gamma={gamma.real:+.4f}{gamma.imag:+.4f}j (|gamma|={abs(gamma):.4f}) | "
              f"sigma_D^2={sigma_d2:.5f} | P_out={p_out:.4f} | disc={disc:.2e}")
        assert sigma_d2 >= 0.0, f"Negative distortion variance for A={a}!"
        assert disc < 1e-5, f"Energy conservation violated for A={a}!"
    print(">> Experiment 1: ALL CHECKS PASSED.")


def run_experiment_2_llr_calibration():
    print("\n" + "=" * 80)
    print("EXPERIMENT 2: 16-QAM Soft LLR Calibration & Extreme Value Numerical Auditing")
    print("=" * 80)

    # 2A: Calibration across SNR regimes (with both estimated CSI and perfect CSI)
    print("\n--- 2A-1: LLR Calibration under DFT-8 Estimated CSI ---")
    snrs = [-5.0, 0.0, 5.0, 10.0, 15.0, 20.0, 30.0]
    
    for snr in snrs:
        frame = generate_frame(
            batch_size=1200,
            n=32,
            snr_db=snr,
            pa_condition="strong",
            A=1.25,
            generator=torch.Generator().manual_seed(100 + int(snr)),
        )
        res = bussgang_lmmse(frame.yp, frame.yd, frame.noise_var, A=1.25, est_method="dft8")
        
        bits_true = frame.bits.view(-1)
        llrs_exact_flat = res.llrs.view(-1)
        hard_bits_flat = res.hard_bits.view(-1)
        
        # MaxLog LLRs for sign check
        llrs_maxlog_flat = calibrated_16qam_llrs(res.z_hat, res.sigma2_eff, method="maxlog").view(-1)
        maxlog_sign_agree = ((llrs_maxlog_flat > 0).long() == hard_bits_flat).float().mean().item()
        exact_sign_agree = ((llrs_exact_flat > 0).long() == hard_bits_flat).float().mean().item()
        
        # Empirical BER of hard slicing vs exact LLR
        ber_hard = (hard_bits_flat != bits_true).float().mean().item()
        ber_exact = ((llrs_exact_flat > 0).long() != bits_true).float().mean().item()
        
        # Predicted Bit Error Probability: E[sigma(-|LLR|)]
        pred_error_prob = torch.sigmoid(-llrs_exact_flat.abs()).mean().item()
        cal_gap = abs(ber_exact - pred_error_prob)
        
        # BCE
        bce = F.binary_cross_entropy_with_logits(llrs_exact_flat, bits_true.float()).item()
        
        print(f"SNR {snr:5.1f} dB | BER(hard): {ber_hard:.4f} | BER(exact): {ber_exact:.4f} | "
              f"E[sigma(-|LLR|)]: {pred_error_prob:.4f} | Gap: {cal_gap:.4f} | "
              f"Sign Match: [MaxLog: {maxlog_sign_agree*100:.1f}%, Exact: {exact_sign_agree*100:.1f}%]")
        
        # MaxLog must match hard slicing 100%
        assert maxlog_sign_agree == 1.0, f"MaxLog sign mismatch at SNR {snr} dB!"
        # In multipath fading, faded subcarriers have low local SNR where exact bit-MAP
        # legitimately achieves lower BER than nearest-neighbor hard slicing.
        # Sign agreement reaches >98% at 15 dB and >99.5% at 25 dB.
        if snr >= 25.0:
            assert exact_sign_agree >= 0.995, f"Exact sign mismatch at high SNR {snr} dB!"
        elif snr >= 15.0:
            assert exact_sign_agree >= 0.98, f"Exact sign mismatch at SNR {snr} dB!"

    print("\n--- 2A-2: LLR Calibration under Known Channel (Perfect CSI) ---")
    for snr in [-5.0, 0.0, 10.0, 20.0, 30.0]:
        frame = generate_frame(
            batch_size=1200,
            n=32,
            snr_db=snr,
            pa_condition="strong",
            A=1.25,
            generator=torch.Generator().manual_seed(150 + int(snr)),
        )
        res_perf = bussgang_lmmse(frame.yp, frame.yd, frame.noise_var, A=1.25, h_true=frame.h_true)
        
        bits_true = frame.bits.view(-1)
        llrs_flat = res_perf.llrs.view(-1)
        ber_exact = ((llrs_flat > 0).long() != bits_true).float().mean().item()
        pred_error_prob = torch.sigmoid(-llrs_flat.abs()).mean().item()
        cal_gap = abs(ber_exact - pred_error_prob)
        
        print(f"SNR {snr:5.1f} dB (Perf CSI) | BER: {ber_exact:.5f} | "
              f"E[sigma(-|LLR|)]: {pred_error_prob:.5f} | Cal Gap: {cal_gap:.5f}")
        assert cal_gap < 0.008, f"Calibration gap {cal_gap} too high under perfect CSI at SNR {snr} dB!"

    # 2B: Numerical Robustness of Exact vs MaxLog under Extreme Inputs
    print("\n--- 2B: Numerical Robustness: Exact LogSumExp vs MaxLog ---")
    extreme_cases = [
        ("Huge amplitude (z=1000)", torch.tensor([1000.0 + 1000.0j]), torch.tensor([1.0])),
        ("Gigantic amplitude (z=1e7)", torch.tensor([1e7 + 1e7j]), torch.tensor([1.0])),
        ("Tiny amplitude (z=1e-8)", torch.tensor([1e-8 + 1e-8j]), torch.tensor([1.0])),
        ("Huge variance (sigma2=1e8)", torch.tensor([1.0 + 1.0j]), torch.tensor([1e8])),
        ("Tiny variance (sigma2=1e-8)", torch.tensor([1.0 + 1.0j]), torch.tensor([1e-8])),
        ("Tiny var + huge amp", torch.tensor([1e5 + 1e5j]), torch.tensor([1e-8])),
        ("Zero amp + min variance", torch.tensor([0.0 + 0.0j]), torch.tensor([1e-15])),
    ]
    
    for desc, z_in, s2_in in extreme_cases:
        llr_exact = calibrated_16qam_llrs(z_in, s2_in, method="exact")
        llr_maxlog = calibrated_16qam_llrs(z_in, s2_in, method="maxlog")
        
        nan_exact = torch.isnan(llr_exact).any().item()
        inf_exact = torch.isinf(llr_exact).any().item()
        nan_maxlog = torch.isnan(llr_maxlog).any().item()
        inf_maxlog = torch.isinf(llr_maxlog).any().item()
        
        print(f"Case: {desc:30s} | Exact (NaN={nan_exact}, Inf={inf_exact}) val={llr_exact[0, 0].item():+.2e} | "
              f"MaxLog (NaN={nan_maxlog}, Inf={inf_maxlog}) val={llr_maxlog[0, 0].item():+.2e}")
        assert not nan_exact and not inf_exact, f"Exact produced NaN/Inf on {desc}!"
        assert not nan_maxlog and not inf_maxlog, f"MaxLog produced NaN/Inf on {desc}!"

    # 2C: Exact vs MaxLog Fidelity and LLR Discrepancy
    print("\n--- 2C: Exact vs MaxLog Approximations Across 100k Constellation Samples ---")
    N_s = 100000
    g = torch.Generator().manual_seed(999)
    bits_syn = torch.randint(0, 2, (N_s, 4), generator=g)
    sym_syn = q16(bits_syn)
    for snr in [0.0, 10.0, 20.0]:
        sigma2 = 10.0 ** (-snr / 10.0)
        noise = (torch.randn(N_s, generator=g) + 1j * torch.randn(N_s, generator=g)) * math.sqrt(sigma2 / 2.0)
        z = sym_syn + noise
        
        llr_ex = calibrated_16qam_llrs(z, torch.tensor([sigma2]), method="exact")
        llr_ml = calibrated_16qam_llrs(z, torch.tensor([sigma2]), method="maxlog")
        
        bce_ex = F.binary_cross_entropy_with_logits(llr_ex, bits_syn.float()).item()
        bce_ml = F.binary_cross_entropy_with_logits(llr_ml, bits_syn.float()).item()
        max_diff = (llr_ex - llr_ml).abs().max().item()
        mean_diff = (llr_ex - llr_ml).abs().mean().item()
        sign_mismatch = ((llr_ex > 0) != (llr_ml > 0)).float().mean().item()
        
        print(f"SNR {snr:4.1f} dB | BCE Exact: {bce_ex:.4f} vs MaxLog: {bce_ml:.4f} | "
              f"LLR diff mean: {mean_diff:.3f}, max: {max_diff:.3f} | Sign mismatch: {sign_mismatch*100:.3f}%")
        assert bce_ex <= bce_ml + 1e-4, f"Exact BCE should be <= MaxLog BCE at SNR {snr} dB!"
        # Max-log approximation error is bounded by ln(2) ~ 0.6931
        assert max_diff <= math.log(2.0) + 1e-2, f"MaxLog error exceeded theoretical bound ln(2) at SNR {snr} dB!"
        if snr >= 10.0:
            assert sign_mismatch < 0.001, f"High sign mismatch at SNR {snr} dB!"
    print(">> Experiment 2: ALL CHECKS PASSED.")


def run_experiment_3_dd_pa_stress():
    print("\n" + "=" * 80)
    print("EXPERIMENT 3: Iterative DD-PA Cancellation Stress Testing")
    print("=" * 80)

    # 3A: DD-PA Error Reduction Under Strong PA Distortion (A=1.25)
    print("\n--- 3A: DD-PA Monotonic Error Reduction across Distortion-Limited SNRs (A=1.25, 3 iterations) ---")
    snrs = [18.0, 20.0, 25.0, 30.0]
    for snr in snrs:
        frame = generate_frame(
            batch_size=1200,
            n=32,
            snr_db=snr,
            pa_condition="strong",
            A=1.25,
            generator=torch.Generator().manual_seed(200 + int(snr)),
        )
        _, _, _, history = iterative_dd_pa_cancellation(
            frame.yp, frame.yd, frame.noise_var, A=1.25, iterations=3, est_method="dft8"
        )
        
        bers = [(rec.hard_bits != frame.bits).float().mean().item() for rec in history]
        mses = [(rec.z_hat - frame.data_tx).abs().square().mean().item() for rec in history]
        
        print(f"SNR {snr:4.1f} dB | "
              f"BER: [Iter0: {bers[0]:.4f} -> Iter1: {bers[1]:.4f} -> Iter2: {bers[2]:.4f} -> Iter3: {bers[3]:.4f}] | "
              f"MSE: [Iter0: {mses[0]:.4f} -> Iter1: {mses[1]:.4f} -> Iter2: {mses[2]:.4f} -> Iter3: {mses[3]:.4f}]")
        
        # Under strong PA at distortion-limited SNRs (>=18 dB), DD-PA must strictly improve over Iteration 0
        assert bers[1] < bers[0], f"Iter 1 BER did not improve over Iter 0 at SNR {snr} dB!"
        assert mses[1] < mses[0], f"Iter 1 MSE did not improve over Iter 0 at SNR {snr} dB!"
        assert bers[2] <= bers[1] + 1e-4, f"Iter 2 diverged at SNR {snr} dB!"

    # 3B: Low SNR & Severe Noise: Does DD-PA diverge or blow up?
    print("\n--- 3B: Low SNR Divergence & Stability Stress Test ---")
    low_snrs = [-10.0, -5.0, -2.0, 0.0, 2.0, 5.0]
    for snr in low_snrs:
        frame = generate_frame(
            batch_size=800,
            n=32,
            snr_db=snr,
            pa_condition="strong",
            A=1.25,
            generator=torch.Generator().manual_seed(300 + int(snr)),
        )
        _, _, _, history = iterative_dd_pa_cancellation(
            frame.yp, frame.yd, frame.noise_var, A=1.25, iterations=3, est_method="dft8"
        )
        
        bers = [(rec.hard_bits != frame.bits).float().mean().item() for rec in history]
        mses = [(rec.z_hat - frame.data_tx).abs().square().mean().item() for rec in history]
        nans = [torch.isnan(rec.z_hat).any().item() or torch.isnan(rec.llrs).any().item() for rec in history]
        infs = [torch.isinf(rec.z_hat).any().item() or torch.isinf(rec.llrs).any().item() for rec in history]
        
        print(f"SNR {snr:5.1f} dB | BER: [{bers[0]:.4f}, {bers[1]:.4f}, {bers[2]:.4f}, {bers[3]:.4f}] | "
              f"MSE: [{mses[0]:.2f}, {mses[1]:.2f}, {mses[2]:.2f}, {mses[3]:.2f}] | "
              f"NaN: {any(nans)} | Inf: {any(infs)}")
        assert not any(nans), f"NaN encountered at low SNR {snr} dB!"
        assert not any(infs), f"Inf encountered at low SNR {snr} dB!"
        # Bounded MSE: MSE should never explode to infinity, and iterations should not diverge relative to Iter 0
        for it_idx, mse_val in enumerate(mses):
            assert mse_val < 100.0, f"MSE exploded to {mse_val} at iter {it_idx}, SNR {snr} dB!"
            assert mse_val <= 1.25 * mses[0] + 0.1, f"MSE diverged by >25% at iter {it_idx}, SNR {snr} dB!"

    # 3C: Channel Estimation Error Stress Test
    print("\n--- 3C: Channel Estimation Error Stress Test ---")
    error_levels = [0.0, 0.05, 0.1, 0.2, 0.5, 1.0] # Channel estimation NMSE
    for err in error_levels:
        frame = generate_frame(
            batch_size=500,
            n=32,
            snr_db=20.0,
            pa_condition="strong",
            A=1.25,
            generator=torch.Generator().manual_seed(400 + int(err * 100)),
        )
        # Add synthetic channel error to yp
        yp_corrupt = frame.yp + (torch.randn_like(frame.yp) + 1j * torch.randn_like(frame.yp)) * math.sqrt(err / 2.0)
        
        _, _, _, history = iterative_dd_pa_cancellation(
            yp_corrupt, frame.yd, frame.noise_var, A=1.25, iterations=3, est_method="dft8"
        )
        bers = [(rec.hard_bits != frame.bits).float().mean().item() for rec in history]
        mses = [(rec.z_hat - frame.data_tx).abs().square().mean().item() for rec in history]
        nans = [torch.isnan(rec.z_hat).any().item() for rec in history]
        
        print(f"Channel Error Var {err:4.2f} | "
              f"BER: [{bers[0]:.4f} -> {bers[1]:.4f} -> {bers[2]:.4f} -> {bers[3]:.4f}] | "
              f"MSE: [{mses[0]:.4f} -> {mses[1]:.4f} -> {mses[2]:.4f} -> {mses[3]:.4f}] | "
              f"NaN: {any(nans)}")
        assert not any(nans), f"NaN with channel error {err}!"
        assert mses[-1] < 20.0, f"MSE exploded under channel error {err}!"

    # 3D: Hard Decisions vs Soft Decisions under Strong PA
    print("\n--- 3D: Hard Decisions vs Soft Decisions in DD-PA ---")
    for snr in [5.0, 15.0, 25.0]:
        frame = generate_frame(
            batch_size=1000,
            n=32,
            snr_db=snr,
            pa_condition="strong",
            A=1.25,
            generator=torch.Generator().manual_seed(500 + int(snr)),
        )
        # Hard decisions
        _, _, _, hist_hard = iterative_dd_pa_cancellation(
            frame.yp, frame.yd, frame.noise_var, A=1.25, iterations=2, use_soft_decisions=False
        )
        # Soft decisions
        _, _, _, hist_soft = iterative_dd_pa_cancellation(
            frame.yp, frame.yd, frame.noise_var, A=1.25, iterations=2, use_soft_decisions=True
        )
        
        ber_hard = [(rec.hard_bits != frame.bits).float().mean().item() for rec in hist_hard]
        ber_soft = [(rec.hard_bits != frame.bits).float().mean().item() for rec in hist_soft]
        
        print(f"SNR {snr:4.1f} dB | Hard BER: [{ber_hard[0]:.4f} -> {ber_hard[1]:.4f} -> {ber_hard[2]:.4f}] | "
              f"Soft BER: [{ber_soft[0]:.4f} -> {ber_soft[1]:.4f} -> {ber_soft[2]:.4f}]")
        assert not torch.isnan(hist_soft[-1].llrs).any(), "Soft decisions produced NaN!"
    print(">> Experiment 3: ALL CHECKS PASSED.")


if __name__ == "__main__":
    run_experiment_1_lmmse_numerical()
    run_experiment_2_llr_calibration()
    run_experiment_3_dd_pa_stress()
    print("\n" + "#" * 80)
    print("### ALL ADVERSARIAL CHALLENGES COMPLETED WITH ZERO ERRORS / FAILURES ###")
    print("#" * 80)
