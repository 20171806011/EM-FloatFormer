"""Empirical Adversarial Stress Test Suite for Milestone 1 (Stage P4-0).

Probes:
1. Static-Limit Parity Check:
   - Sweeps N in {16, 32, 64, 128}
   - Sweeps CP in {8, 16, 32} with CP <= N
   - Sweeps oversample factor L in {4, 8, 16}
   - Standard profiles (train3, equal4, long6, long12, sparse12)
   - Randomized multipath profiles (varying tap counts, exponential decay, random delays)
   - Linear PA limit with A=None and A=1e5
   - Boundary checks: CP < max_delay, and CP > N
2. Rapp PA Model under Extreme Parameters:
   - Severe clipping A in {0.5, 0.8, 1.0, 1.25, 2.25}
   - Linear limit A -> 10^5
   - Extreme AM-PM alpha in {0.0, 0.5, 1.5, 3.0}
   - Amplitude compression g(r) <= A, saturation asymptote
   - Phase rotation matching Phi(r)
   - Extreme inputs: zeros, tiny (1e-12), huge (1e4), NaN/Inf robustness
3. Doppler ICI:
   - Sweep fd in [0.0, 0.25]
   - Verify transfer matrix is strictly diagonal at fd=0
   - Verify off-diagonal ICI power grows strictly monotonically with fd
   - Verify analytical transfer matrix matches time-domain FIR convolution exactly across fd sweep
"""

import math
import sys
import os
from typing import Dict, List, Tuple

import torch
import torch.nn.functional as F

# Ensure p4 is importable
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import p4
from p4.simulator import (
    DEFAULT_CP,
    DEFAULT_N,
    PROFILES,
    DynamicChannelSimulator,
    ChannelState,
    apply_rapp_pa_samples,
    decimate_time_to_frequency,
    oversample_frequency_to_time,
    q16,
    qpsk,
    rapp_am_am,
    rapp_am_pm,
    rapp_pa,
    complex_randn,
)


def run_probe_1_static_parity() -> Dict[str, any]:
    print("=" * 70)
    print("PROBE 1: Static-Limit Parity Check Stress Test")
    print("=" * 70)

    g = torch.Generator().manual_seed(2026)

    # 1.1 Sweep across N, CP, L, standard profiles
    N_list = [16, 32, 64, 128]
    CP_list = [8, 16, 32]
    L_list = [4, 8, 16]

    print("\n--- 1.1 Grid Sweep: (N, CP, L, Profiles) ---")
    grid_failures = 0
    grid_total = 0
    max_rel_err = 0.0

    for n in N_list:
        for cp in CP_list:
            if cp > n:
                # In standard OFDM, CP is a prefix of length CP <= N.
                continue
            for l in L_list:
                for prof_name, pdp_tuple in PROFILES.items():
                    max_delay = len(pdp_tuple) - 1
                    if max_delay > cp:
                        continue

                    grid_total += 1
                    sim = DynamicChannelSimulator(n=n, cp=cp, profile=prof_name, fd=0.0)
                    ch = sim.draw_channel(64, generator=g)

                    # Q16 symbols
                    data_bits = torch.randint(0, 2, (64, n, 4), generator=g)
                    x_freq = q16(data_bits)

                    # Time domain with linear PA at oversample L
                    x_time = torch.fft.ifft(x_freq, norm="ortho")
                    # Test both A=None and A=1e5 (finite linear limit)
                    for a_val in [None, 1e5]:
                        x_pa = rapp_pa(x_time, knee=2.0, A=a_val, alpha=0.0, oversample=l)
                        x_cp = torch.cat((x_pa[:, -cp:], x_pa), dim=-1)

                        y_time = sim.filter_time_signal(x_cp, ch, noise_var=None)
                        y_rx = torch.fft.fft(y_time[:, cp:], norm="ortho")
                        y_ref = ch.h_freq_static * x_freq

                        rel_err = ((y_rx - y_ref).norm() / (y_ref.norm() + 1e-12)).item()
                        if rel_err > max_rel_err:
                            max_rel_err = rel_err
                        passed = rel_err < 1e-5
                        if not passed:
                            grid_failures += 1
                            print(f"[FAIL] N={n}, CP={cp}, L={l}, prof={prof_name}, A={a_val}: rel_err={rel_err:.2e}")

    print(f"Grid sweep complete: {grid_total} configurations tested, {grid_failures} failures.")
    print(f"Max observed relative error in grid sweep: {max_rel_err:.2e} (< 1e-5: {max_rel_err < 1e-5})")

    # 1.2 Randomized Multipath Profiles
    print("\n--- 1.2 Randomized Multipath Profiles (Random Taps, Delays, Decay) ---")
    rand_failures = 0
    rand_total = 50
    rand_max_rel_err = 0.0

    for i in range(rand_total):
        n = int(torch.randint(0, 4, (1,)).item())
        n = [16, 32, 64, 128][n]
        # Ensure CP <= n
        valid_cps = [c for c in [8, 16, 32] if c <= n]
        cp = valid_cps[int(torch.randint(0, len(valid_cps), (1,)).item())]
        l = int(torch.randint(0, 3, (1,)).item())
        l = [4, 8, 16][l]

        num_taps = int(torch.randint(1, min(cp + 1, 16), (1,)).item())
        # Random exponential decay profile
        decay = float(torch.empty(1).uniform_(0.1, 0.8).item())
        pdp = [math.exp(-decay * t) for t in range(num_taps)]
        pdp_sum = sum(pdp)
        pdp = [p / pdp_sum for p in pdp]

        # Register custom profile temporarily in PROFILES
        cust_name = f"_rand_prof_{i}"
        PROFILES[cust_name] = tuple(pdp)

        try:
            sim = DynamicChannelSimulator(n=n, cp=cp, profile=cust_name, fd=0.0)
            ch = sim.draw_channel(64, generator=g)

            data_bits = torch.randint(0, 2, (64, n, 4), generator=g)
            x_freq = q16(data_bits)
            x_time = torch.fft.ifft(x_freq, norm="ortho")
            x_pa = rapp_pa(x_time, knee=2.0, A=None, alpha=0.0, oversample=l)
            x_cp = torch.cat((x_pa[:, -cp:], x_pa), dim=-1)

            y_time = sim.filter_time_signal(x_cp, ch, noise_var=None)
            y_rx = torch.fft.fft(y_time[:, cp:], norm="ortho")
            y_ref = ch.h_freq_static * x_freq

            rel_err = ((y_rx - y_ref).norm() / (y_ref.norm() + 1e-12)).item()
            if rel_err > rand_max_rel_err:
                rand_max_rel_err = rel_err
            if rel_err >= 1e-5:
                rand_failures += 1
                print(f"[FAIL] Random profile {i}: N={n}, CP={cp}, L={l}, taps={num_taps}: rel_err={rel_err:.2e}")
        finally:
            del PROFILES[cust_name]

    print(f"Randomized profiles complete: {rand_total} tests, {rand_failures} failures.")
    print(f"Max observed relative error in randomized profiles: {rand_max_rel_err:.2e} (< 1e-5: {rand_max_rel_err < 1e-5})")

    # 1.3 Boundary Checks
    print("\n--- 1.3 Boundary Checks ---")
    # Check A: CP < max delay raises ValueError
    boundary_delay_passed = False
    try:
        sim = DynamicChannelSimulator(n=32, cp=8, profile="long12", fd=0.0)
    except ValueError as e:
        boundary_delay_passed = True
        print(f"[PASS] Correctly caught exception when CP < max_delay: '{e}'")

    # Check B: CP > N behavior
    # When CP > N (e.g. N=16, CP=32), slicing x_time[:, -32:] clamps to length 16.
    # Total signal length is 16 + 16 = 32 != 48, so filter_time_signal asserts.
    cp_exceeds_n_caught = False
    try:
        from p4.simulator import generate_frame
        f = generate_frame(batch_size=1, n=16, cp=32, profile="equal4")
    except AssertionError as e:
        cp_exceeds_n_caught = True
        print(f"[NOTE] Boundary condition CP > N (N=16, CP=32) caught by assertion: '{e}'")

    return {
        "grid_total": grid_total,
        "grid_failures": grid_failures,
        "max_rel_err": max_rel_err,
        "rand_total": rand_total,
        "rand_failures": rand_failures,
        "rand_max_rel_err": rand_max_rel_err,
        "boundary_delay_passed": boundary_delay_passed,
        "cp_exceeds_n_caught": cp_exceeds_n_caught,
    }


def run_probe_2_rapp_pa() -> Dict[str, any]:
    print("\n" + "=" * 70)
    print("PROBE 2: Rapp PA Extreme Parameters Stress Test")
    print("=" * 70)

    # 2.1 Saturation bounds check across severe clipping
    A_list = [0.5, 0.8, 1.0, 1.25, 2.25]
    r_sweep = torch.logspace(-2, 3, 200)  # 0.01 to 1000

    print("\n--- 2.1 Amplitude Compression g(r) <= A and Asymptote ---")
    bound_violations = 0
    for a in A_list:
        g_r = rapp_am_am(r_sweep, A=a, knee=2.0)
        # Check strict inequality g(r) < A for all finite r
        if not torch.all(g_r < a):
            bound_violations += 1
            print(f"[FAIL] g(r) exceeded A for A={a}: max g(r)={g_r.max().item()}")
        # Check monotonic increase
        diffs = g_r[1:] - g_r[:-1]
        if not torch.all(diffs >= 0):
            print(f"[FAIL] g(r) is not monotonically increasing for A={a}")
        # Check asymptote at r=1000: should be within 0.01% of A
        asymptote_err = abs(g_r[-1].item() - a) / a
        if asymptote_err > 1e-3:
            print(f"[WARN] Asymptote error for A={a}: {asymptote_err:.2e}")
        else:
            print(f"[PASS] A={a:4.2f}: max g(r)={g_r.max().item():.6f} < A, asymptote relative error={asymptote_err:.2e}")

    # 2.2 Linear limit: A -> 10^5
    print("\n--- 2.2 Linear Limit: A -> 10^5 ---")
    g_linear = rapp_am_am(r_sweep, A=1e5, knee=2.0)
    linear_diff = (g_linear - r_sweep).abs().max().item()
    print(f"Max absolute deviation from identity for A=1e5 across r in [0.01, 1000]: {linear_diff:.2e}")

    # 2.3 Extreme AM-PM phase rotation
    print("\n--- 2.3 Extreme AM-PM Phase Distortion alpha in {0.0, 0.5, 1.5, 3.0} ---")
    alpha_list = [0.0, 0.5, 1.5, 3.0]
    beta = 1.0
    ampm_failures = 0

    for alpha in alpha_list:
        phi_r = rapp_am_pm(r_sweep, alpha=alpha, beta=beta)
        if alpha == 0.0:
            if not torch.all(phi_r == 0.0):
                ampm_failures += 1
                print(f"[FAIL] alpha=0 produced non-zero phase: {phi_r.abs().max().item()}")
        else:
            # Check monotonic increase with r
            diffs = phi_r[1:] - phi_r[:-1]
            if not torch.all(diffs >= -1e-7):
                ampm_failures += 1
                print(f"[FAIL] phi(r) not monotonically increasing for alpha={alpha}")
            # Check asymptote: lim_{r->inf} alpha * r^2 / (1 + r^2) = alpha
            asymptote = alpha * (beta ** 2)
            phi_inf = phi_r[-1].item()
            err = abs(phi_inf - asymptote) / asymptote
            print(f"[PASS] alpha={alpha:4.1f}: phi(r=1000)={phi_inf:.6f}, theoretical asymptote={asymptote:.6f}, err={err:.2e}")

    # 2.4 End-to-end sample phase rotation verification
    print("\n--- 2.4 Phase Rotation Fidelity in apply_rapp_pa_samples ---")
    phase_fidelity_failures = 0
    for alpha in alpha_list:
        for a in [1.25, 2.25]:
            # Random complex samples
            x = (torch.randn(1000, dtype=torch.float32) + 1j * torch.randn(1000, dtype=torch.float32))
            x_pa = apply_rapp_pa_samples(x, A=a, alpha=alpha, beta=beta)

            r = x.abs()
            expected_g = rapp_am_am(r, A=a)
            expected_phi = rapp_am_pm(r, alpha=alpha, beta=beta)

            actual_g = x_pa.abs()
            amp_err = (actual_g - expected_g).abs().max().item()

            actual_angle = torch.angle(x_pa)
            # Phase difference wrapped to [-pi, pi]
            phase_diff = torch.remainder(actual_angle - torch.angle(x) - expected_phi + math.pi, 2 * math.pi) - math.pi
            phase_err = phase_diff.abs().max().item()

            if amp_err > 1e-6 or phase_err > 1e-5:
                phase_fidelity_failures += 1
                print(f"[FAIL] A={a}, alpha={alpha}: amp_err={amp_err:.2e}, phase_err={phase_err:.2e}")

    print(f"Phase and amplitude fidelity tests complete: {phase_fidelity_failures} failures.")

    # 2.5 Numerical Extremes & NaN/Inf Robustness
    print("\n--- 2.5 Numerical Extremes (0.0, 1e-15, 1e4, complex zeros) ---")
    x_extremes = torch.tensor([0.0 + 0.0j, 1e-15 + 0.0j, 0.0 + 1e-15j, 1e4 + 1e4j, -1e4 + 0.0j], dtype=torch.complex64)
    x_pa_ext = rapp_pa(x_extremes.unsqueeze(0), knee=2.0, A=1.25, alpha=0.5, beta=1.0, oversample=4).squeeze(0)

    has_nan = torch.isnan(x_pa_ext.real).any() or torch.isnan(x_pa_ext.imag).any()
    has_inf = torch.isinf(x_pa_ext.real).any() or torch.isinf(x_pa_ext.imag).any()

    print(f"Extremes input: {x_extremes.numpy()}")
    print(f"Extremes output magnitude: {x_pa_ext.abs().numpy()}")
    print(f"Contains NaN: {has_nan.item()}, Contains Inf: {has_inf.item()}")

    # Check zero preservation
    zero_out = x_pa_ext[0].abs().item()
    print(f"Zero input produces output magnitude: {zero_out:.2e}")

    # 2.6 Energy bounds under oversampled PA
    print("\n--- 2.6 Average Output Power vs Saturation Bound ---")
    # For unit-power OFDM signal (E[|x|^2]=1), as A decreases, P_out must decrease monotonically
    p_outs = []
    g = torch.Generator().manual_seed(101)
    x_test = complex_randn((100, 32), generator=g)
    for a in [2.25, 1.25, 1.0, 0.8, 0.5]:
        x_pa = rapp_pa(x_test, knee=2.0, A=a, alpha=0.5, beta=1.0, oversample=4)
        p_out = (x_pa.abs() ** 2).mean().item()
        p_outs.append((a, p_out))
        print(f"A={a:4.2f}: Output power P_out = {p_out:.4f} (Input P_in = 1.0000)")

    # Verify P_out < P_in and monotonic decrease
    p_out_monotonic = all(p_outs[i][1] < p_outs[i-1][1] for i in range(1, len(p_outs)))
    print(f"P_out strictly monotonic decrease with stronger clipping: {p_out_monotonic}")

    return {
        "bound_violations": bound_violations,
        "linear_diff": linear_diff,
        "ampm_failures": ampm_failures,
        "phase_fidelity_failures": phase_fidelity_failures,
        "has_nan": bool(has_nan.item()),
        "has_inf": bool(has_inf.item()),
        "p_out_monotonic": p_out_monotonic,
    }


def run_probe_3_doppler_ici() -> Dict[str, any]:
    print("\n" + "=" * 70)
    print("PROBE 3: Doppler ICI & Transfer Matrix Stress Test")
    print("=" * 70)

    fd_sweep = [0.0, 0.005, 0.01, 0.02, 0.04, 0.06, 0.08, 0.10, 0.15, 0.20, 0.25]
    n = 32
    cp = 16
    eye_mask = torch.eye(n, dtype=torch.bool)

    # 3.1 Check exact diagonality at fd=0
    print("\n--- 3.1 Diagonality at fd = 0.0 ---")
    sim_0 = DynamicChannelSimulator(n=n, cp=cp, profile="equal4", fd=0.0)
    g = torch.Generator().manual_seed(42)
    ch_0 = sim_0.draw_channel(100, generator=g)
    H_mat_0 = sim_0.compute_transfer_matrix(ch_0)  # (100, N, N)

    off_diag_0 = H_mat_0[:, ~eye_mask].abs().square().sum(dim=-1).mean().item()
    diag_0 = torch.diagonal(H_mat_0, dim1=1, dim2=2)
    diag_diff = (diag_0 - ch_0.h_freq_static).abs().max().item()

    print(f"fd=0.0 average off-diagonal power: {off_diag_0:.2e}")
    print(f"fd=0.0 max absolute diff between diag(H_mat) and h_freq_static: {diag_diff:.2e}")
    diag_passed = off_diag_0 < 1e-10 and diag_diff < 1e-5
    print(f"fd=0 Diagonality check: {'PASS' if diag_passed else 'FAIL'}")

    # 3.2 Monotonic growth of ICI off-diagonal power across fd sweep
    print("\n--- 3.2 Monotonic Growth of ICI Power Across fd in [0.0, 0.25] ---")
    h_init_fixed = complex_randn((1, 4), generator=g) * (torch.tensor([0.25, 0.25, 0.25, 0.25]).sqrt())
    angles_fixed = torch.rand((1, 4), generator=g) * (2.0 * math.pi)
    delays_fixed = torch.arange(4)

    off_diag_powers_fixed = []
    total_powers_fixed = []
    ratio_powers_fixed = []

    for fd_val in fd_sweep:
        sim = DynamicChannelSimulator(n=n, cp=cp, profile="equal4", fd=fd_val)
        ch_state = ChannelState(
            h_time_initial=h_init_fixed,
            delays=delays_fixed,
            fd_shifts=fd_val * torch.cos(angles_fixed),
            h_freq_static=torch.fft.fft(h_init_fixed, n=n, dim=-1),
        )
        H_mat = sim.compute_transfer_matrix(ch_state)[0]
        off_pwr = H_mat[~eye_mask].abs().square().sum().item()
        tot_pwr = H_mat.abs().square().sum().item()
        off_diag_powers_fixed.append(off_pwr)
        total_powers_fixed.append(tot_pwr)
        ratio_powers_fixed.append(off_pwr / tot_pwr)

    print(f"{'fd':>6} | {'Off-Diag Pwr':>14} | {'Total Pwr':>12} | {'ICI Ratio (%)':>14}")
    print("-" * 52)
    for fd_val, off_pwr, tot_pwr, ratio in zip(fd_sweep, off_diag_powers_fixed, total_powers_fixed, ratio_powers_fixed):
        print(f"{fd_val:6.3f} | {off_pwr:14.6e} | {tot_pwr:12.6f} | {ratio * 100:13.4f}%")

    # Check strict monotonicity for fd > 0
    mono_violations = 0
    for i in range(1, len(off_diag_powers_fixed)):
        if off_diag_powers_fixed[i] <= off_diag_powers_fixed[i - 1]:
            mono_violations += 1
            print(f"[FAIL] Monotonicity violated between fd={fd_sweep[i-1]} and fd={fd_sweep[i]}")

    print(f"Monotonicity test (fixed channel): {mono_violations} violations across {len(fd_sweep)-1} intervals.")

    # Test B: Monte Carlo ensemble average (B=500 random channels per fd)
    print("\n--- 3.3 Monte Carlo Ensemble Average (B=500 per fd) ---")
    mc_off_powers = []
    for fd_val in fd_sweep:
        sim = DynamicChannelSimulator(n=n, cp=cp, profile="equal4", fd=fd_val)
        ch = sim.draw_channel(500, generator=g)
        H_mat = sim.compute_transfer_matrix(ch)
        mean_off_pwr = H_mat[:, ~eye_mask].abs().square().sum(dim=-1).mean().item()
        mc_off_powers.append(mean_off_pwr)

    print(f"{'fd':>6} | {'MC Mean Off-Diag Pwr':>22}")
    print("-" * 32)
    for fd_val, mc_pwr in zip(fd_sweep, mc_off_powers):
        print(f"{fd_val:6.3f} | {mc_pwr:22.6e}")

    mc_mono_violations = 0
    for i in range(1, len(mc_off_powers)):
        if mc_off_powers[i] <= mc_off_powers[i - 1]:
            mc_mono_violations += 1
            print(f"[FAIL] MC Monotonicity violated between fd={fd_sweep[i-1]} and fd={fd_sweep[i]}")

    print(f"Monte Carlo Monotonicity test: {mc_mono_violations} violations.")

    # 3.4 Verification of H_mat @ X vs continuous time-domain FIR convolution
    print("\n--- 3.4 Equivalence of Transfer Matrix H_mat and Continuous Time FIR ---")
    fir_mat_diffs = []
    for fd_val in [0.0, 0.02, 0.05, 0.10, 0.25]:
        sim = DynamicChannelSimulator(n=n, cp=cp, profile="train3", fd=fd_val)
        ch = sim.draw_channel(32, generator=g)
        H_mat = sim.compute_transfer_matrix(ch)  # (32, N, N)

        # Transmit 32 random frequency symbols
        X = complex_randn((32, n), generator=g)  # (32, N)
        Y_mat = torch.bmm(H_mat, X.unsqueeze(-1)).squeeze(-1)  # (32, N)

        # Time domain filtering
        x_time = torch.fft.ifft(X, norm="ortho")
        x_cp = torch.cat((x_time[:, -cp:], x_time), dim=-1)
        y_time = sim.filter_time_signal(x_cp, ch, noise_var=None)
        Y_fir = torch.fft.fft(y_time[:, cp:], norm="ortho")

        max_diff = (Y_fir - Y_mat).abs().max().item()
        rel_diff = ((Y_fir - Y_mat).norm() / Y_mat.norm()).item()
        fir_mat_diffs.append((fd_val, max_diff, rel_diff))
        print(f"fd={fd_val:4.2f}: max |Y_fir - Y_mat| = {max_diff:.2e}, rel diff = {rel_diff:.2e}")

    max_fir_mat_err = max(d[1] for d in fir_mat_diffs)

    return {
        "diag_passed": diag_passed,
        "off_diag_0": off_diag_0,
        "mono_violations": mono_violations,
        "mc_mono_violations": mc_mono_violations,
        "max_fir_mat_err": max_fir_mat_err,
        "fir_mat_passed": max_fir_mat_err < 1e-5,
    }


if __name__ == "__main__":
    p1 = run_probe_1_static_parity()
    p2 = run_probe_2_rapp_pa()
    p3 = run_probe_3_doppler_ici()

    print("\n" + "=" * 70)
    print("PROBE SUMMARY & VERDICT")
    print("=" * 70)
    print(f"Probe 1 (Static Parity): Grid Failures={p1['grid_failures']}, Rand Failures={p1['rand_failures']}, Max Rel Err={p1['max_rel_err']:.2e}, Boundary={p1['boundary_delay_passed']}")
    print(f"Probe 2 (Rapp PA): Bound Violations={p2['bound_violations']}, NaN={p2['has_nan']}, Inf={p2['has_inf']}, Linear Diff={p2['linear_diff']:.2e}, P_out Monotonic={p2['p_out_monotonic']}")
    print(f"Probe 3 (Doppler ICI): Diag={p3['diag_passed']} (off-diag {p3['off_diag_0']:.2e}), Mono Violations={p3['mono_violations']}, MC Mono Violations={p3['mc_mono_violations']}, FIR-Mat Match={p3['fir_mat_passed']} (max err {p3['max_fir_mat_err']:.2e})")
