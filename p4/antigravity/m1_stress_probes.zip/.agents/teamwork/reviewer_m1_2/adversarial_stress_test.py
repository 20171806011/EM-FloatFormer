"""Adversarial stress testing for Stage P4-0 simulator and classical baselines.
"""

import math
import sys
import os
sys.path.insert(0, os.path.abspath("."))
import torch
import torch.nn.functional as F

import p4
from p4.simulator import (
    rapp_am_am,
    rapp_am_pm,
    rapp_pa,
    DynamicChannelSimulator,
    generate_frame,
    static_limit_parity_check,
    q16,
    hard_bits_16qam,
    DEFAULT_N,
    DEFAULT_CP,
)
from p4.classical_baselines import (
    bussgang_params,
    bussgang_lmmse,
    calibrated_16qam_llrs,
    iterative_dd_pa_cancellation,
    soft_slice_16qam,
    delay_est_dft,
)

def run_adversarial_tests():
    print("=== Starting Adversarial Stress Tests ===")
    failures = []

    # 1. Zero noise test
    print("\n[Test 1] Zero noise test (nv = 0.0)")
    try:
        frame = generate_frame(batch_size=10, snr_db=100.0, pa_condition="mild")
        nv_zero = torch.zeros_like(frame.noise_var)
        res = bussgang_lmmse(frame.yp, frame.yd, nv_zero, A=2.25)
        if torch.isnan(res.llrs).any() or torch.isinf(res.llrs).any():
            failures.append("Zero noise produced NaN/Inf in LLRs")
        if torch.isnan(res.z_hat).any() or torch.isinf(res.z_hat).any():
            failures.append("Zero noise produced NaN/Inf in z_hat")
        print("  Pass: Zero noise handled gracefully without NaN or Inf.")
    except Exception as e:
        failures.append(f"Zero noise raised exception: {e}")

    # 2. Extreme low SNR (infinite noise)
    print("\n[Test 2] Extreme low SNR test (nv = 1e6)")
    try:
        frame = generate_frame(batch_size=10, snr_db=-60.0, pa_condition="mild")
        # Test with estimated channel
        res_est = bussgang_lmmse(frame.yp, frame.yd, frame.noise_var, A=2.25)
        if torch.isnan(res_est.llrs).any() or torch.isinf(res_est.llrs).any():
            failures.append("Extreme noise produced NaN/Inf in LLRs (est)")
        # Test with true channel
        res_true = bussgang_lmmse(frame.yp, frame.yd, frame.noise_var, A=2.25, h_true=frame.h_true)
        if torch.isnan(res_true.llrs).any() or torch.isinf(res_true.llrs).any():
            failures.append("Extreme noise produced NaN/Inf in LLRs (true)")
        mean_abs_llr_true = res_true.llrs.abs().mean().item()
        print(f"  Pass: Extreme noise handled gracefully (with h_true mean |LLR| = {mean_abs_llr_true:.4e})")
        if mean_abs_llr_true > 0.01:
            failures.append(f"Expected uninformative LLRs ~0 with h_true under extreme noise, got {mean_abs_llr_true}")
    except Exception as e:
        failures.append(f"Extreme noise raised exception: {e}")

    # 3. Deep channel fade test (H -> 0)
    print("\n[Test 3] Deep channel fade (Yp = 0, Yd = 0)")
    try:
        yp_zero = torch.zeros((4, DEFAULT_N), dtype=torch.complex64)
        yd_zero = torch.zeros((4, DEFAULT_N), dtype=torch.complex64)
        nv = torch.ones((4, 1), dtype=torch.float32)
        res = bussgang_lmmse(yp_zero, yd_zero, nv, A=1.25)
        if torch.isnan(res.llrs).any() or torch.isinf(res.llrs).any():
            failures.append("Zero channel produced NaN/Inf in LLRs")
        print("  Pass: Deep channel fade handled safely without division by zero.")
    except Exception as e:
        failures.append(f"Deep channel fade raised exception: {e}")

    # 4. Extreme PA saturation limits (A -> infinity, A -> 0.05)
    print("\n[Test 4] Extreme PA saturation limits")
    try:
        # A = inf
        g_inf, sig_inf, p_inf = bussgang_params(A=math.inf, alpha=0.0)
        assert abs(g_inf - 1.0) < 1e-6 and sig_inf == 0.0 and p_inf == 1.0
        print("  Pass: A=inf returns exact identity parameters (gamma=1, sigma_D=0).")

        # A = 0.05 (extreme clipping)
        g_clip, sig_clip, p_clip = bussgang_params(A=0.05, alpha=0.5)
        print(f"  Pass: Extreme clipping A=0.05: gamma={g_clip:.4f}, sigma_D2={sig_clip:.4f}, p_out={p_clip:.4f}")
        assert not math.isnan(g_clip.real) and not math.isnan(sig_clip)
    except Exception as e:
        failures.append(f"Extreme PA saturation raised exception: {e}")

    # 5. Extreme Doppler shifts (fd = 0.5)
    print("\n[Test 5] Extreme Doppler shift (fd = 0.5)")
    try:
        sim_high = DynamicChannelSimulator(n=32, cp=16, profile="train3", fd=0.5)
        g = torch.Generator().manual_seed(42)
        ch = sim_high.draw_channel(2, generator=g)
        H_mat = sim_high.compute_transfer_matrix(ch)
        x_time = torch.randn(2, 48, dtype=torch.complex64)
        y_time = sim_high.filter_time_signal(x_time, ch)
        if torch.isnan(y_time).any() or torch.isinf(y_time).any():
            failures.append("Extreme Doppler produced NaN/Inf in time signal")
        if torch.isnan(H_mat).any() or torch.isinf(H_mat).any():
            failures.append("Extreme Doppler produced NaN/Inf in transfer matrix")
        print("  Pass: Extreme Doppler fd=0.5 computed stably.")
    except Exception as e:
        failures.append(f"Extreme Doppler raised exception: {e}")

    # 6. Extreme symbol inputs to LLR function
    print("\n[Test 6] Extreme symbol inputs to calibrated_16qam_llrs")
    try:
        # Very large z
        z_extreme = torch.tensor([[1000.0 + 1000.0j, -1000.0 - 1000.0j, 0.0 + 0.0j]], dtype=torch.complex64)
        sigma2 = torch.tensor([[0.1, 0.1, 0.1]], dtype=torch.float32)
        llrs_exact = calibrated_16qam_llrs(z_extreme, sigma2, method="exact")
        llrs_maxlog = calibrated_16qam_llrs(z_extreme, sigma2, method="maxlog")

        if torch.isnan(llrs_exact).any() or torch.isinf(llrs_exact).any():
            failures.append("Exact LLR produced NaN/Inf on extreme inputs")
        if torch.isnan(llrs_maxlog).any() or torch.isinf(llrs_maxlog).any():
            failures.append("MaxLog LLR produced NaN/Inf on extreme inputs")
        print(f"  Pass: Extreme inputs handled cleanly (exact LLR range: [{llrs_exact.min().item():.1f}, {llrs_exact.max().item():.1f}]).")
    except Exception as e:
        failures.append(f"Extreme LLR inputs raised exception: {e}")

    # 7. Soft decisions in Iterative DD-PA
    print("\n[Test 7] Soft decisions in iterative_dd_pa_cancellation")
    try:
        frame = generate_frame(batch_size=50, snr_db=18.0, pa_condition="strong", A=1.25)
        h_hat, llrs_soft, bits_soft, hist_soft = iterative_dd_pa_cancellation(
            frame.yp, frame.yd, frame.noise_var, A=1.25, iterations=2, use_soft_decisions=True
        )
        h_hat, llrs_hard, bits_hard, hist_hard = iterative_dd_pa_cancellation(
            frame.yp, frame.yd, frame.noise_var, A=1.25, iterations=2, use_soft_decisions=False
        )
        ber_soft = (bits_soft != frame.bits).float().mean().item()
        ber_hard = (bits_hard != frame.bits).float().mean().item()
        print(f"  Pass: DD-PA with soft decisions BER = {ber_soft:.4f}, hard decisions BER = {ber_hard:.4f}")
    except Exception as e:
        failures.append(f"DD-PA soft decisions raised exception: {e}")

    # 8. Single symbol and large batch boundary tests
    print("\n[Test 8] Single symbol and large batch boundary tests")
    try:
        frame1 = generate_frame(batch_size=1, n=32)
        res1 = bussgang_lmmse(frame1.yp, frame1.yd, frame1.noise_var)
        assert res1.llrs.shape == (1, 32, 4)

        frame512 = generate_frame(batch_size=512, n=32)
        res512 = bussgang_lmmse(frame512.yp, frame512.yd, frame512.noise_var)
        assert res512.llrs.shape == (512, 32, 4)
        print("  Pass: Batch size 1 and 512 function identically without dimension collapse.")
    except Exception as e:
        failures.append(f"Batch dimension test raised exception: {e}")

    # Summary
    print("\n=== Adversarial Stress Test Summary ===")
    if failures:
        print(f"FAILED ({len(failures)} failures):")
        for f in failures:
            print(f"  - {f}")
        sys.exit(1)
    else:
        print("ALL ADVERSARIAL STRESS TESTS PASSED CLEANLY (8/8).")

if __name__ == "__main__":
    run_adversarial_tests()
