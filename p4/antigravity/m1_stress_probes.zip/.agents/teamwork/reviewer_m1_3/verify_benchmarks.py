import json
import csv
from pathlib import Path

timing_path = Path("p4/results/timing.json")
csv_path = Path("p4/results/latency_cpu.csv")

assert timing_path.exists(), "timing.json does not exist"
assert csv_path.exists(), "latency_cpu.csv does not exist"

with open(timing_path, "r", encoding="utf-8") as f:
    timing = json.load(f)

print("Timing metadata:")
for k, v in timing.items():
    if k != "results":
        print(f"  {k}: {v}")

assert timing["num_threads"] == 4, f"Expected 4 threads, got {timing['num_threads']}"
assert timing["device"] == "cpu", f"Expected cpu, got {timing['device']}"
assert len(timing["results"]) == 12, f"Expected 12 results, got {len(timing['results'])}"

print("\nBenchmark Results Summary:")
for r in timing["results"]:
    assert r["warmup_runs"] == 25, f"Expected 25 warmup, got {r['warmup_runs']}"
    assert r["timed_runs"] == 100, f"Expected 100 timed runs, got {r['timed_runs']}"
    assert r["threads"] == 4, f"Expected 4 threads, got {r['threads']}"
    assert r["device"] == "cpu", f"Expected cpu, got {r['device']}"
    assert r["median_ms"] > 0, "Median latency must be positive"
    print(f"  {r['method']:16s} | B={r['batch_size']:2d} | Median={r['median_ms']:6.3f} ms | P95={r['p95_ms']:6.3f} ms | Mean={r['mean_ms']:6.3f} ms")

with open(csv_path, "r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    rows = list(reader)

assert len(rows) == 12, f"Expected 12 rows, got {len(rows)}"
for r in rows:
    assert int(r["warmup_runs"]) == 25
    assert int(r["timed_runs"]) == 100
    assert int(r["threads"]) == 4
    assert float(r["median_ms"]) > 0

print("\n[VERIFIED] ALL 12 production benchmark records verified: 25 warmup, 100 timed runs, 4 CPU threads!")
