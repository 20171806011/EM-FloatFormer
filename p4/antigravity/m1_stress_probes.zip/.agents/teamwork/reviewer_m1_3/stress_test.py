import math
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

import torch
import torch.nn.functional as F
import p4
from p4.simulator import (
    DynamicChannelSimulator,
    apply_rapp_pa_samples,
    rapp_pa,
    generate_frame,
    static_limit_parity_check,
    q16,
)
from p4.classical_baselines import (
    bussgang_params,
    bussgang_lmmse,
    calibrated_16qam_llrs,
    delay_est_dft,
    hard_slice_16qam,
    iterative_dd_pa_cancellation,
)

print("Starting Adversarial Stress Testing...")

# -------------------------------------------------------------
# 1. Stress Test: Calibrated 16-QAM LLRs Extreme Boundaries
# -------------------------------------------------------------
print("\n[Test 1] LLR Extreme Dynamic Range & Boundaries:")
for method in ["exact", "maxlog"]:
    # Case A: Very high SNR (sigma2 = 1e-6)
    z_extreme = torch.tensor([0.0 + 0.0j, 10.0 + 10.0j, -10.0 - 10.0j, 1e-4 + 1e-4j], dtype=torch.complex64)
    sigma2_tiny = torch.full((4,), 1e-6)
    llrs = calibrated_16qam_llrs(z_extreme, sigma2_tiny, method=method)
    assert not torch.isnan(llrs).any(), f"NaN in LLRs ({method}, tiny sigma2)"
    assert not torch.isinf(llrs).any(), f"Inf in LLRs ({method}, tiny sigma2)"

    # Case B: Very low SNR (sigma2 = 1e4)
    sigma2_huge = torch.full((4,), 1e4)
    llrs_low = calibrated_16qam_llrs(z_extreme, sigma2_huge, method=method)
    assert not torch.isnan(llrs_low).any(), f"NaN in LLRs ({method}, huge sigma2)"
    assert not torch.isinf(llrs_low).any(), f"Inf in LLRs ({method}, huge sigma2)"
    assert (llrs_low.abs() < 1.0).all(), f"LLRs should be close to 0 under extreme noise"

    # Case C: Extreme coordinates (|z| = 1000)
    z_giant = torch.tensor([1000.0 + 0j, -1000.0 - 1000.0j], dtype=torch.complex64)
    sigma2_mid = torch.tensor([0.1, 0.1])
    llrs_giant = calibrated_16qam_llrs(z_giant, sigma2_mid, method=method)
    assert not torch.isnan(llrs_giant).any(), f"NaN in giant z ({method})"

print("  PASS: LLR computation is numerically stable without NaNs/Infs across 10 orders of magnitude.")

# -------------------------------------------------------------
# 2. Stress Test: Rapp PA Non-saturation and Oversampling
# -------------------------------------------------------------
print("\n[Test 2] Rapp PA Boundary and Invariance:")
# Zero input
x_zero = torch.zeros(5, 32, dtype=torch.complex64)
y_zero = rapp_pa(x_zero, A=1.25, oversample=4)
assert torch.all(y_zero == 0.0), "Zero input must produce zero output"

# Gigantic input
x_huge = torch.full((2, 32), 1e5 + 1e5j, dtype=torch.complex64)
y_huge = rapp_pa(x_huge, A=1.25, oversample=4)
assert not torch.isnan(y_huge).any(), "NaN in huge input"
assert not torch.isinf(y_huge).any(), "Inf in huge input"
assert (y_huge.abs() <= 1.25 + 1e-4).all(), f"PA output magnitude must not exceed A=1.25, got {y_huge.abs().max()}"

# Oversampling factor 1, 2, 4, 8
for L in [1, 2, 4, 8]:
    x_test = torch.randn(4, 32, dtype=torch.complex64)
    y_lin = rapp_pa(x_test, A=None, alpha=0.0, oversample=L)
    diff = (y_lin - x_test).abs().max().item()
    assert diff < 1e-5, f"Linear PA failed at oversample={L}: diff={diff}"
print("  PASS: Rapp PA preserves boundaries and oversampling invertibility (L=1, 2, 4, 8).")

# -------------------------------------------------------------
# 3. Stress Test: Bussgang Decomposition Quadrature Limits
# -------------------------------------------------------------
print("\n[Test 3] Bussgang Parameters Monotonicity & Limits:")
# As A increases towards infinity, gamma -> 1.0, sigma_d2 -> 0.0, p_out -> 1.0
gamma_lin, sigma_d2_lin, pout_lin = bussgang_params(A=None, alpha=0.0)
assert gamma_lin == (1.0 + 0j) and sigma_d2_lin == 0.0 and pout_lin == 1.0

# As A decreases (stronger distortion), sigma_d2 must increase
_, d2_mild, _ = bussgang_params(A=2.25, alpha=0.5)
_, d2_strong, _ = bussgang_params(A=1.25, alpha=0.5)
assert d2_strong > d2_mild > 0.0, f"Expected d2_strong ({d2_strong}) > d2_mild ({d2_mild})"
print(f"  Bussgang sigma_D^2: A=2.25 -> {d2_mild:.4f}, A=1.25 -> {d2_strong:.4f} (monotonic)")
print("  PASS: Bussgang parameters satisfy physical monotonicity.")

# -------------------------------------------------------------
# 4. Stress Test: Iterative DD-PA with Soft Decisions & Iterations
# -------------------------------------------------------------
print("\n[Test 4] DD-PA Robustness across Modes:")
g = torch.Generator().manual_seed(777)
frame = generate_frame(batch_size=100, n=32, cp=16, profile="long6", snr_db=15.0, pa_condition="strong", A=1.25, generator=g)

# Iterations = 0 (should return cleanly matching Bussgang)
h0, llr0, bits0, hist0 = iterative_dd_pa_cancellation(frame.yp, frame.yd, frame.noise_var, A=1.25, iterations=0)
assert len(hist0) == 1
assert torch.all(bits0 == hist0[0].hard_bits)

# Iterations = 3 with hard decisions
h_hard, llr_hard, bits_hard, hist_hard = iterative_dd_pa_cancellation(frame.yp, frame.yd, frame.noise_var, A=1.25, iterations=3, use_soft_decisions=False)
assert len(hist_hard) == 4

# Iterations = 3 with soft decisions
h_soft, llr_soft, bits_soft, hist_soft = iterative_dd_pa_cancellation(frame.yp, frame.yd, frame.noise_var, A=1.25, iterations=3, use_soft_decisions=True)
assert len(hist_soft) == 4

# Linear PA (A=None) should return immediately after iteration 0
h_lin, llr_lin, bits_lin, hist_lin = iterative_dd_pa_cancellation(frame.yp, frame.yd, frame.noise_var, A=None, iterations=3)
assert len(hist_lin) == 1
print("  PASS: DD-PA executes correctly across hard/soft modes, iteration counts (0 to 3), and linear bypass.")

# -------------------------------------------------------------
# 5. Stress Test: Delay DFT Channel Estimation Generalization
# -------------------------------------------------------------
print("\n[Test 5] Delay DFT Estimation Generalization:")
for N_sub in [16, 32, 64, 128]:
    yp_test = torch.randn(8, N_sub, dtype=torch.complex64)
    h_est = delay_est_dft(yp_test, taps=4)
    assert h_est.shape == (8, N_sub), f"Expected shape (8, {N_sub}), got {h_est.shape}"
print("  PASS: Delay DFT estimator handles N=16, 32, 64, 128 seamlessly.")

print("\nALL ADVERSARIAL STRESS TESTS COMPLETED SUCCESSFULLY!")
