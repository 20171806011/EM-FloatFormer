"""Matched P4-A readout study on real encoded OFDM frames."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import tempfile

import torch

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_json(path, data):
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf8", dir=path.parent, delete=False) as output:
        json.dump(data, output, indent=2, allow_nan=False)
        output.write("\n")
        pending=Path(output.name)
    try:
        os.replace(pending,path)
    finally:
        pending.unlink(missing_ok=True)

def data(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def weights_hash(model):
    h=hashlib.sha256()
    for k,t in sorted(model.state_dict().items()):
        h.update(json.dumps([k,str(t.dtype),list(t.shape)],separators=(",",":")).encode())
        h.update(t.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()

def checkpoint(folder,name,seed,factory,protocol,replay):
    from p4.em_floatformer import _train_comparative_model
    target=folder/"weights"/f"{name}_{seed}.pt"
    target.parent.mkdir(exist_ok=True,parents=True)
    cfg=protocol["train"]
    if replay or target.is_file():
        payload=torch.load(target,weights_only=True,map_location="cpu")
        if payload["actual_seed"]!=seed or payload["protocol_sha256"]!=PROTOCOL_HASH or payload["method"]!=name:
            raise ValueError(f"Incorrect study checkpoint {target}")
        model=factory()
        model.load_state_dict(payload["weights"],strict=True)
        model.eval()
        if weights_hash(model)!=payload["sha256"]:
            raise ValueError(f"Weight fingerprint differs for {target}")
        return model
    model,_=_train_comparative_model(factory,steps=cfg["steps"],batch_size=cfg["batch"],n_sc=32,
        profile=cfg["profile"],seed=seed,has_gamma_eff=True,backbone_lr=cfg[name]["backbone_lr"],
        gamma_lr=cfg[name]["gamma_lr"])
    info=dict(method=name,actual_seed=seed,weights=model.state_dict(),sha256=weights_hash(model),protocol_sha256=PROTOCOL_HASH)
    with tempfile.NamedTemporaryFile(dir=target.parent,delete=False) as f: pending=Path(f.name)
    try:
        torch.save(info,pending)
        os.replace(pending,target)
    finally:
        pending.unlink(missing_ok=True)
    return model

def anchor_check(root,name,model):
    from p4.simulator import generate_frame
    table=data(root/"p4/results/p4a_comparative_benchmark.json")["rows"]
    checks=[]
    for snr in (10,30):
        row,=[r for r in table if r["method"]==name and r["snr_db"]==snr and r["pa_condition"]=="strong"]
        f=generate_frame(batch_size=256,n=32,profile="equal4",snr_db=float(snr),pa_condition="strong",
                         generator=torch.Generator().manual_seed(row["eval_seed"]))
        with torch.inference_mode():
            l=model(f.yp,f.yd,f.noise_var)["llrs"]
        errors=int(((l>0)!=f.bits).sum())
        checks.append({"snr_db":snr,"heldout_seed":row["eval_seed"],"bits":f.bits.numel(),
                       "bit_errors":errors,"archived_bit_errors":row["bit_errors"],"exact":errors==row["bit_errors"]})
    return checks

def measure(model,group,protocol):
    from waveforms import make_frame
    from readouts import score_frame
    n=protocol["evaluation"]["frames_per_seed_condition"]
    batch=protocol["evaluation"]["batch"]
    assert n%batch==0
    cells=[]
    for ci,(pa,snr) in enumerate(protocol["conditions"]):
        summaries={arm:dict(block_failures="",bit_errors=0,raw_errors=0,bce_sum=0.,llr_abs_max=0.,above_8=0,
                            llr_count=0) for arm in protocol["settings"]}
        public_checks=0
        for b in range(n//batch):
            wave=31800000+group*100000+ci*1000+b
            payload=41200000+group*100000+ci*1000+b
            frame,info=make_frame(pa,snr,batch,wave,payload)
            with torch.inference_mode():
                batch_rows=score_frame(model,frame,info,protocol["settings"])
            assert set(batch_rows)==set(summaries)
            for arm,stats in batch_rows.items():
                dst=summaries[arm]
                flags=stats["block_flags"]
                assert len(flags)==batch and all(int(v) in (0,1) for v in flags)
                assert len(flags)==info.shape[0] and stats["llr_count"]==batch*128
                assert all(math.isfinite(float(stats[k])) for k in ("bce_sum","llr_abs_max"))
                dst["block_failures"]+="".join(str(int(x)) for x in flags)
                for key in ("bit_errors","raw_errors","above_8","llr_count","bce_sum"):
                    dst[key]+=stats[key]
                dst["llr_abs_max"]=max(dst["llr_abs_max"],stats["llr_abs_max"])
            assert batch_rows["signed"]["public_max_error"]==0
            public_checks+=1
        for rec in summaries.values():
            assert len(rec["block_failures"])==n and rec["llr_count"]==128*n
            rec["block_errors"]=rec["block_failures"].count("1")
            assert rec["block_errors"]<=rec["bit_errors"]<=64*rec["block_errors"]
        cells.append(dict(pa=pa,snr_db=snr,blocks=n,info_bits=64*n,coded_bits=128*n,
                          signed_public_checks=public_checks,settings=summaries))
    return cells

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root",type=Path,required=True)
    p.add_argument("--output",type=Path,required=True)
    p.add_argument("--replay",action="store_true",help="Reuse the recorded trained weights and verify every integer and paired frame outcome")
    args=p.parse_args()
    root=args.root.resolve()
    out=args.output.resolve()
    package=Path(__file__).resolve().parent
    sys.path.insert(0,str(root))
    from p4.em_floatformer import EMFloatFormer,LocalEquivConv16QAM
    from waveforms import verify_waveforms
    protocol=data(package/"protocol.json")
    if sha(package/"protocol.json")!=PROTOCOL_HASH: raise ValueError("Study protocol changed")
    torch.set_num_threads(protocol["train"]["threads"])
    out.mkdir(exist_ok=True,parents=True)
    paths=["p4/simulator.py","p4/em_floatformer.py","p4/slot_2d.py","p4/classical_baselines.py",
           "p4/results/p4a_comparative_benchmark.json"]
    sources={path:sha(root/path) for path in paths}
    sources.update({name:sha(package/name) for name in ("run.py","readouts.py","waveforms.py","protocol.json")})
    output={"protocol_sha256":PROTOCOL_HASH,"source_sha256":sources,"torch_version":str(torch.__version__),
            "waveform_controls":verify_waveforms(),"rows":[]}
    archived=data(out/"raw.json") if args.replay else None
    factories={"EMFloatFormer":lambda:EMFloatFormer(d_model=12,n_heads=2,depth=2,n_sc=32),
               "LocalEquivConv16QAM":lambda:LocalEquivConv16QAM(width=14,kernel_size=5,depth=2,ffn_dim=12)}
    for name,factory in factories.items():
        for i,base in enumerate(protocol["model_groups"]):
            seed=base+protocol["train"][name]["seed_offset"]
            model=checkpoint(out,name,seed,factory,protocol,args.replay)
            result={"method":name,"group":base,"training_seed":seed,"weights_sha256":weights_hash(model),
                    "parameter_count":sum(p.numel() for p in model.parameters()),
                    "archived_checks":anchor_check(root,name,model) if base==2026 else [],
                    "conditions":measure(model,i,protocol)}
            output["rows"].append(result)
            if args.replay and result!=archived["rows"][len(output["rows"])-1]:
                raise ValueError(f"Readout replay mismatch for {name} seed {seed}")
            print(f"{'Replayed' if args.replay else 'Completed'} {name}, seed {seed}, {len(result['conditions'])} conditions",flush=True)
    if args.replay:
        if output!=archived: raise ValueError("Complete metadata or waveform checks differ")
        print("All 8 weights, 88 waveforms sets, 440 readout cells and 225280 paired block decisions replayed exactly.",flush=True)
    else:
        write_json(out/"raw.json",output)

PROTOCOL_HASH="1fb9a98f7100df8a8982e8087714117ded0e9073da4658e693979520db8f36fe"

if __name__=="__main__":
    main()

