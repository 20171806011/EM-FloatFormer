"""Summarize the paired 1D P4-A coded-readout results using only the Python standard library."""
import argparse
from collections import Counter
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import tempfile


METHODS = ("EMFloatFormer", "LocalEquivConv16QAM")
COUNT_KEYS = ("blocks", "block_errors", "info_bits", "info_bit_errors", "coded_bits",
              "raw_bit_errors", "llr_count", "above_8")
PAIR_KEYS = ("old_failed_signed_passed", "old_passed_signed_failed", "both_failed", "both_passed")


def require(ok, message):
    if not ok:
        raise ValueError(message)


def count(value, label):
    require(type(value) is int and value >= 0, f"Invalid nonnegative integer for {label}")
    return value


def finite(value, label):
    require(type(value) in (int, float) and math.isfinite(value) and value >= 0, f"Invalid {label}")
    return value


def pair_flags(old, signed):
    require(len(old) == len(signed) and len(old) > 0, "Unpaired frame counts")
    require(isinstance(old, str) and isinstance(signed, str) and set(old+signed) <= {"0", "1"},
            "Invalid failure strings")
    pairs = Counter(zip(old, signed))
    return dict(zip(PAIR_KEYS, (pairs["1","0"], pairs["0","1"], pairs["1","1"], pairs["0","0"])))


def summarize_pair(rows):
    totals = {key: sum(r[key] for r in rows) for key in PAIR_KEYS}
    blocks = sum(totals.values())
    delta = totals["old_failed_signed_passed"] - totals["old_passed_signed_failed"]
    return dict(totals, blocks=blocks, net_blocks_saved=delta, old_minus_signed_bler=delta / blocks)


def summarize_arm(rows):
    data = {key: sum(r[key] for r in rows) for key in COUNT_KEYS}
    bce = math.fsum(r["bce_sum"] for r in rows)
    data.update(bce_sum=bce, llr_abs_max=max(r["llr_abs_max"] for r in rows),
                bler=data["block_errors"] / data["blocks"],
                information_ber=data["info_bit_errors"] / data["info_bits"],
                raw_coded_ber=data["raw_bit_errors"] / data["coded_bits"],
                mean_bce_nats_per_coded_bit=bce / data["llr_count"],
                fraction_abs_llr_greater_than_8=data["above_8"] / data["llr_count"])
    return data


def read_arm(record, blocks, cap, label):
    flags = record["block_failures"]
    require(isinstance(flags, str) and len(flags) == blocks and set(flags) <= {"0", "1"},
            f"Invalid per-frame string for {label}")
    failures = flags.count("1")
    require(count(record["block_errors"], label) == failures, f"Block count differs from flags for {label}")
    wrong = count(record["bit_errors"], label)
    raw = count(record["raw_errors"], label)
    llrs = count(record["llr_count"], label)
    above = count(record["above_8"], label)
    bce = finite(record["bce_sum"], label)
    maximum = finite(record["llr_abs_max"], label)
    require(failures <= wrong <= 64*failures, f"Impossible decoded bit errors in {label}")
    require(llrs == blocks*128 and raw <= llrs and above <= llrs, f"Invalid coded-bit counts in {label}")
    require(maximum <= cap and (above > 0) == (maximum > 8), f"Invalid LLR range in {label}")
    return {"blocks": blocks, "block_errors": failures, "info_bits": blocks*64, "info_bit_errors": wrong,
            "coded_bits": blocks*128, "raw_bit_errors": raw, "above_8": above,
            "llr_count": llrs, "llr_abs_max": maximum, "bce_sum": bce}


def analyze(raw, spec, protocol_hash):
    require(raw["protocol_sha256"] == protocol_hash and raw["source_sha256"]["protocol.json"] == protocol_hash,
            "Raw-file protocol hashes disagree with the protocol bytes")
    groups = spec["model_groups"]
    conditions = [tuple(c) for c in spec["conditions"]]
    settings = spec["settings"]
    require(len(groups) == len(set(groups)) == 4 and len(set(conditions)) == len(conditions) == 11,
            "Expected all four fit groups and eleven distinct conditions")
    require(len(settings) == 5 and settings["old"] == [.05, 8] and settings["signed"] == [.035, 20],
            "Unexpected arm definitions")
    per_group = spec["evaluation"]["frames_per_seed_condition"]
    batch = spec["evaluation"]["batch"]
    require(per_group == 512 and batch == 32, "Unexpected evaluation sample structure")
    expected = {(method, group) for method in METHODS for group in groups}
    indexed = {}
    for row in raw["rows"]:
        key = row["method"], row["group"]
        require(key in expected and key not in indexed, f"Unexpected or duplicate model group {key}")
        method, group = key
        require(row["training_seed"] == group + spec["train"][method]["seed_offset"],
                f"Incorrect training seed in {key}")
        lookup = {}
        for cell in row["conditions"]:
            condition = cell["pa"], cell["snr_db"]
            require(condition in conditions and condition not in lookup, f"Unexpected or duplicate {key}, {condition}")
            label = f"{key}, {condition}"
            require(cell["blocks"] == per_group and cell["info_bits"] == 64*per_group
                    and cell["coded_bits"] == 128*per_group, f"Incorrect denominators in {label}")
            require(cell["signed_public_checks"] == per_group//batch, f"Incomplete public-forward controls in {label}")
            require(set(cell["settings"]) == set(settings), f"Missing or unexpected arm in {label}")
            stats = {name: read_arm(cell["settings"][name], per_group, limits[1], f"{label}, {name}")
                     for name, limits in settings.items()}
            pair = pair_flags(cell["settings"]["old"]["block_failures"],
                              cell["settings"]["signed"]["block_failures"])
            require(pair[PAIR_KEYS[0]] - pair[PAIR_KEYS[1]] == stats["old"]["block_errors"]
                    - stats["signed"]["block_errors"], f"Directional pairing failed in {label}")
            lookup[condition] = stats, pair
        require(set(lookup) == set(conditions), f"Incomplete conditions for {key}")
        indexed[key] = row, lookup
    require(set(indexed) == expected, "Incomplete data: all eight trained model groups are required")
    methods = {}
    for method in METHODS:
        cells = []
        for ci, condition in enumerate(conditions):
            arms = {arm: [] for arm in settings}
            pairs, per_seed = [], []
            for gi, group in enumerate(groups):
                row, lookup = indexed[method, group]
                observed, pair = lookup[condition]
                pairs.append(pair)
                for arm in settings:
                    arms[arm].append(observed[arm])
                per_seed.append({"group": group, "training_seed": row["training_seed"], "waveform_group_index": gi,
                                 "condition_index": ci, "paired_old_to_signed": summarize_pair([pair]),
                                 "arms": {arm: summarize_arm([observed[arm]]) for arm in settings}})
            pairing = summarize_pair(pairs)
            deltas = [p[PAIR_KEYS[0]] - p[PAIR_KEYS[1]] for p in pairs]
            pairing["training_groups_net_positive_zero_negative"] = [sum(d > 0 for d in deltas),
                                                                    sum(d == 0 for d in deltas),
                                                                    sum(d < 0 for d in deltas)]
            cells.append({"pa": condition[0], "snr_db": condition[1], "frames": per_group*len(groups),
                          "arms": {arm: summarize_arm(observations) for arm, observations in arms.items()},
                          "paired_old_to_signed": pairing, "by_training_seed": per_seed})
        methods[method] = {"training_groups": [
            {"group": g, "training_seed": indexed[method, g][0]["training_seed"],
             "weights_sha256": indexed[method, g][0]["weights_sha256"]} for g in groups], "conditions": cells}
    unique_frames = len(groups)*len(conditions)*per_group
    return {"protocol_sha256": protocol_hash, "settings_floor_and_tanh_scale": settings, "methods": methods,
            "sampling": {"unique_physical_frames": unique_frames, "frames_per_architecture_condition": per_group*len(groups),
                         "architecture_frame_evaluations": unique_frames*len(METHODS),
                         "arm_frame_evaluations": unique_frames*len(METHODS)*len(settings),
                         "common_waveform_key": ["waveform_group_index","condition_index","batch_index","frame_in_batch"],
                         "payload_and_wave_seed_rules": [spec["evaluation"]["info_seed"], spec["evaluation"]["wave_seed"]],
                         "interpretation": "Both architectures and all readouts share the waveform under the same key. Four training fits per architecture, each evaluated on its own waveform group."},
            "metrics": {"block_errors": "Recounted independently from the per-frame failure strings, checked against stored counts.",
                        "paired_old_to_signed": "First cell counts old failed / signed passed. A positive old-minus-signed BLER indicates fewer errors with signed.",
                        "other_metrics": "Information BER, raw coded BER, coded-bit BCE and the strict |LLR|>8 fraction use the recorded per-model/arm error or sum totals and their bit denominators. Per-bit observations are not stored."}}


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("raw", type=Path)
    cli.add_argument("--output", type=Path, required=True)
    cli.add_argument("--protocol", type=Path, default=Path(__file__).with_name("protocol.json"))
    args = cli.parse_args()
    require(args.output.resolve() not in (args.protocol.resolve(), args.raw.resolve()), "Output must be separate from inputs")
    result = analyze(read(args.raw), read(args.protocol), sha256(args.protocol.read_bytes()).hexdigest())
    result["raw_sha256"] = sha256(args.raw.read_bytes()).hexdigest()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", dir=args.output.parent, encoding="utf-8", delete=False) as stream:
        pending = Path(stream.name)
        try:
            json.dump(result, stream, indent=2, allow_nan=False)
            stream.write("\n")
        except BaseException:
            stream.close()
            pending.unlink(missing_ok=True)
            raise
    try:
        os.replace(pending, args.output)
    finally:
        pending.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
