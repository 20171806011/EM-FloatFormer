"""Read-only paired LLR readouts on the official P4-A EM and local convolutional receivers."""
import math
import sys

import torch
from torch.nn import functional as F

from p4.classical_baselines import calibrated_16qam_llrs
from p4.em_floatformer import EMFloatFormer, LocalEquivConv16QAM
from p4.slot_2d import _get_default_ldpc, decode_min_sum


PUBLIC_FLOOR = .035
PUBLIC_CAP = 20.
SUPPORTED = {EMFloatFormer.forward.__code__, LocalEquivConv16QAM.forward.__code__}


def bitwise_equal(left, right):
    return (left.dtype == right.dtype and left.shape == right.shape
            and torch.equal(left.contiguous().view(torch.uint8), right.contiguous().view(torch.uint8)))


def _public_forward(model, yp, yd, noise_var):
    """Read the completed Python forward frame once, without modifying the model or demapper."""
    forward = model.forward.__func__.__code__
    if forward not in SUPPORTED:
        raise TypeError("Expected the official P4-A EM or LocalEquivConv16QAM forward")
    captured = []

    def collect(frame, event, arg):
        if event == "return" and frame.f_code is forward and arg is not None:
            loc = frame.f_locals
            if loc["self"] is model:
                captured.append(tuple(loc[k] for k in ("z_eq", "nv_exp", "h_power_det", "dist_power_det",
                                                        "sigma_eff2", "llrs64")))

    # Each callback is local to this thread. If an instrumentation tool is already
    # profiling it, use a local return trace instead, preserving that tool's profiler.
    previous_profiler = sys.getprofile()
    if previous_profiler is None:
        sys.setprofile(collect)
        try:
            public = model(yp, yd, noise_var).llrs
        finally:
            sys.setprofile(None)
    else:
        previous_trace = sys.gettrace()
        if previous_trace is not None:
            raise RuntimeError("Simultaneous debugger and profiler already occupy both thread instrumentation slots")
        def trace(frame, event, arg):
            if frame.f_code is forward:
                frame.f_trace_lines = False
                collect(frame, event, arg)
                return trace
            return None
        sys.settrace(trace)
        try:
            public = model(yp, yd, noise_var).llrs
        finally:
            sys.settrace(previous_trace)
    if len(captured) != 1:
        raise RuntimeError(f"Expected one official network forward, captured {len(captured)}")
    return public, captured[0]


@torch.inference_mode()
def predict_readouts(model, yp, yd, noise_var, settings):
    """Prediction-only API: all readouts receive exactly the same observed tensors and weights."""
    if not settings:
        raise ValueError("At least one readout setting is required")
    public, (z, noise, channel_power, distortion_power, official_variance, official_raw) = _public_forward(
        model, yp, yd, noise_var)
    if z.dtype != torch.complex128 or any(x.dtype != torch.float64 for x in
                                           (noise, channel_power, distortion_power, official_variance, official_raw)):
        raise RuntimeError("Official demapper intermediate precision changed")
    base = noise / (channel_power+1e-4) + distortion_power / (channel_power+1e-4)
    if not bitwise_equal(base + PUBLIC_FLOOR, official_variance):
        raise RuntimeError("Reconstructed complete official variance differs before QAM demapping")
    raw = {PUBLIC_FLOOR: calibrated_16qam_llrs(z, base+PUBLIC_FLOOR, method="exact")}
    if not bitwise_equal(raw[PUBLIC_FLOOR], official_raw):
        raise RuntimeError("Reconstructed exact-QAM log likelihoods differ before saturation")
    expected = (PUBLIC_CAP * torch.tanh(raw[PUBLIC_FLOOR]/PUBLIC_CAP)).to(public.dtype)
    if not torch.isfinite(public).all() or not bitwise_equal(expected, public):
        raise RuntimeError("Reconstructed default LLRs differ from the complete public tensor")
    result = {}
    for label, (floor, cap) in settings.items():
        floor = float(floor)
        cap = float("inf") if cap is None else float(cap)
        if not math.isfinite(floor) or floor <= 0 or math.isnan(cap) or cap <= 0:
            raise ValueError(f"Invalid positive variance floor or saturation cap for {label!r}")
        if floor not in raw:
            raw[floor] = calibrated_16qam_llrs(z, base+floor, method="exact")
        if floor == PUBLIC_FLOOR and cap == PUBLIC_CAP:
            values = expected
        elif math.isinf(cap):
            values = raw[floor].to(public.dtype)
        else:
            values = (cap * torch.tanh(raw[floor]/cap)).to(public.dtype)
        if not torch.isfinite(values).all():
            raise FloatingPointError(f"Nonfinite LLRs for {label!r}")
        result[label] = values
    return public, result


@torch.inference_mode()
def score_frame(model, frame, info, settings):
    """Score one physical (128,64) LDPC word per 32-carrier frame; return counts per readout label."""
    public, variants = predict_readouts(model, frame.yp, frame.yd, frame.noise_var, settings)
    batch = public.shape[0]
    if public.shape != (batch,32,4) or frame.bits.shape != public.shape:
        raise ValueError("Expected exactly 32 physical 16-QAM symbols per codeword")
    if info.shape not in ((batch,64),(batch,1,64)):
        raise ValueError("Expected 64 systematic information bits per frame")
    info = info.reshape(batch,64)
    bits = frame.bits.reshape(batch,128)
    if not ((bits==0)|(bits==1)).all() or not ((info==0)|(info==1)).all():
        raise ValueError("Nonbinary scoring labels")
    code = _get_default_ldpc(128)
    result = {}
    for name, values in variants.items():
        llrs = values.reshape(batch,128)
        decoded = decode_min_sum(llrs, code.h_matrix, max_iter=25)
        mismatch = decoded != info
        floor, cap = settings[name]
        public_branch = float(floor)==PUBLIC_FLOOR and cap is not None and float(cap)==PUBLIC_CAP
        result[name] = {"block_flags":mismatch.any(-1).long().tolist(), "bit_errors":int(mismatch.sum()),
                        "raw_errors":int(((llrs>0)!=bits).sum()),
                        "bce_sum":float(F.binary_cross_entropy_with_logits(llrs.double(),bits.double(),reduction="sum")),
                        "llr_abs_max":float(llrs.abs().max()), "above_8":int((llrs.abs()>8).sum()),
                        "llr_count":llrs.numel(),
                        "public_max_error":float((public-values).abs().max()) if public_branch else None}
    return result


def selftest():
    """Coded, unit-channel pilot/payload observations with AWGN; this exercises the API only."""
    from dataclasses import replace
    from p4.simulator import FrameData, q16
    from p4.slot_2d import encode_ldpc

    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)
    generator = torch.Generator().manual_seed(11)
    code = _get_default_ldpc(128)
    info = torch.randint(2,(5,64),generator=generator)
    encoded,_ = encode_ldpc(info,code)
    bits = encoded.reshape(5,32,4)
    tx = q16(bits)
    unit = torch.ones_like(tx)
    nv = torch.full((5,1),.04)
    def noise():
        a = torch.randn(tx.shape,generator=generator)
        b = torch.randn(tx.shape,generator=generator)
        return torch.complex(a,b)*(nv/2).sqrt()
    frame = FrameData(yp=unit+noise(),yd=tx+noise(),bits=bits,h_true=unit,noise_var=nv,pilot_tx=unit,data_tx=tx)
    settings = {"public":(.035,20.),"floor_only":(.12,20.),"cap_only":(.035,6.),"uncapped":(.035,None)}
    output = {}
    for cls in (EMFloatFormer,LocalEquivConv16QAM):
        torch.manual_seed(11)
        model = cls().eval()
        state = {k:v.clone() for k,v in model.state_dict().items()}
        first,variants = predict_readouts(model,frame.yp,frame.yd,frame.noise_var,settings)
        clean = score_frame(model,frame,info,settings)
        changed = replace(frame,bits=1-frame.bits,h_true=frame.h_true*float("nan"),data_tx=-frame.data_tx)
        second,again = predict_readouts(model,changed.yp,changed.yd,changed.noise_var,settings)
        poisoned = score_frame(model,changed,1-info,settings)
        golden = model(frame.yp,frame.yd,frame.noise_var).llrs
        decoded = decode_min_sum(golden.reshape(5,128),code.h_matrix,max_iter=25)
        same_public = all(bitwise_equal(x,golden) for x in (first,second,variants["public"]))
        same_others = all(bitwise_equal(v,again[k]) for k,v in variants.items())
        assert same_public and same_others and clean["public"]["public_max_error"] == 0
        assert all(torch.equal(v,state[k]) for k,v in model.state_dict().items()) and model.training is False
        assert clean["public"]["bit_errors"] == int((decoded!=info).sum())
        assert clean["public"]["raw_errors"] == int(((golden>0)!=bits).sum())
        assert all(clean[k]["raw_errors"]+poisoned[k]["raw_errors"]==640 for k in settings)
        assert all(clean[k]["bit_errors"]+poisoned[k]["bit_errors"]==320 for k in settings)
        assert clean["cap_only"]["llr_abs_max"]<=6.0 and clean["cap_only"]["above_8"]==0
        changed_llrs = {k:int((variants[k]!=golden).sum()) for k in settings if k!="public"}
        assert all(n>0 for n in changed_llrs.values())
        output[cls.__name__] = {"frames":5,"llr_count":640,"public_bitwise_equal":same_public,
            "changed_llrs":changed_llrs,"truth_poison_predictions_identical":same_others,"weights_unchanged":True,
            "public":clean["public"],"cap_only":clean["cap_only"]}
    return output


if __name__ == "__main__":
    import json
    with torch.inference_mode():
        print(json.dumps(selftest(),indent=2,allow_nan=False))
