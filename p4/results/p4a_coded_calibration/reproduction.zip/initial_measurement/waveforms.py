"""Transmit one native (128,64) LDPC word per original 32-tone P4-A data symbol."""
from dataclasses import replace
from hashlib import sha256

import torch

from p4.simulator import (DEFAULT_CP, DEFAULT_N, DEFAULT_OVERSAMPLE, DynamicChannelSimulator,
                          generate_frame, q16, qpsk, rapp_pa)
from p4.slot_2d import _get_default_ldpc, decode_min_sum, encode_ldpc


def _tx(symbols, pa):
    saturation = {"clean": None, "mild": 2.25, "strong": 1.25}[pa]
    time_signal = torch.fft.ifft(symbols, norm="ortho")
    output = rapp_pa(time_signal, A=saturation, alpha=0. if pa == "clean" else .5,
                     beta=1., knee=2., oversample=DEFAULT_OVERSAMPLE)
    return torch.cat((output[:, -DEFAULT_CP:], output), dim=-1)


def _fft(received):
    return torch.fft.fft(received[:, DEFAULT_CP:], norm="ortho")


def _same(a, b, name):
    if a.dtype != b.dtype or a.shape != b.shape or not torch.equal(a, b):
        raise AssertionError(f"Unequal {name}")
    return float((a-b).abs().max())


def _native(pa, snr_db, batch_size, wave_seed):
    if pa not in ("clean", "mild", "strong") or not isinstance(batch_size, int) or batch_size <= 0:
        raise ValueError("Expected clean/mild/strong PA and a positive integer batch size")
    if DEFAULT_N != 32:
        raise ValueError("This one-word-per-data-symbol study requires 32 subcarriers")
    generator = torch.Generator().manual_seed(wave_seed)
    replay = torch.Generator().set_state(generator.get_state())
    frame = generate_frame(batch_size=batch_size, n=DEFAULT_N, cp=DEFAULT_CP, profile="equal4",
                           snr_db=snr_db, fd=0., pa_condition=pa, generator=generator)
    sim = DynamicChannelSimulator(n=DEFAULT_N, cp=DEFAULT_CP, profile="equal4", fd=0.)
    state = sim.draw_channel(batch_size, generator=replay)
    p = qpsk(torch.randint(0, 2, (batch_size, DEFAULT_N, 2), generator=replay))
    original_bits = torch.randint(0, 2, (batch_size, DEFAULT_N, 4), generator=replay)
    if isinstance(snr_db, (tuple, list)):
        snr = torch.empty((batch_size, 1)).uniform_(*snr_db, generator=replay)
    else:
        snr = torch.full((batch_size, 1), float(snr_db))
    noise_var = 10.**(-snr/10.)
    pilot_rng = replay.get_state()
    pilot_rx = sim.filter_time_signal(_tx(p, pa), state, noise_var=noise_var, generator=replay)
    data_rng = replay.get_state()
    checks = {
        "pilot_tx": _same(p, frame.pilot_tx, "pilot symbols"),
        "data_bits": _same(original_bits, frame.bits, "native payload bits"),
        "data_tx": _same(q16(original_bits), frame.data_tx, "native QAM symbols"),
        "noise_var": _same(noise_var, frame.noise_var, "noise variance"),
        "h_true": _same(state.h_freq_static, frame.h_true, "static channel"),
        "yp": _same(_fft(pilot_rx)*p.conj(), frame.yp, "pilot observations"),
    }
    if frame.h_matrix is not None:
        raise AssertionError("Static P4-A returns h_matrix=None")
    return frame, sim, state, pilot_rng, data_rng, generator.get_state(), checks


def _encoded_frame(original, sim, channel, data_rng, pa, info_seed):
    batch = original.bits.size(0)
    code = _get_default_ldpc(128)
    info = torch.randint(0, 2, (batch, code.k), generator=torch.Generator().manual_seed(info_seed))
    words, _ = encode_ldpc(info, code)
    coded_bits = words.reshape(batch, DEFAULT_N, 4)
    symbols = q16(coded_bits)
    received = sim.filter_time_signal(_tx(symbols, pa), channel, noise_var=original.noise_var,
                                      generator=torch.Generator().set_state(data_rng))
    return replace(original, bits=coded_bits, data_tx=symbols, yd=_fft(received)), info, received


@torch.inference_mode()
def make_frame(pa, snr_db, batch_size, wave_seed, info_seed):
    """Return (FrameData, Bx64 information bits); frame.bits holds transmitted Bx32x4 code bits.

    Wave and payload RNG streams are explicit. The original pilot, channel and AWGN are
    retained when info_seed changes. Receivers should consume only frame.yp, .yd and .noise_var.
    """
    original, sim, channel, _, data_rng, _, _ = _native(pa, snr_db, batch_size, wave_seed)
    frame, truth, _ = _encoded_frame(original, sim, channel, data_rng, pa, info_seed)
    return frame, truth


@torch.inference_mode()
def verify_waveforms():
    """Return portable JSON values, including exact whole-tensor and physical AWGN checks."""
    code = _get_default_ldpc(128)
    records = []
    conditions = [("clean", 30., 3), ("mild", 18., 5), ("strong", 24., 7),
                  ("strong", (15., 30.), 9)]
    for i, (pa, snr, batch) in enumerate(conditions):
        wave_seed, info_seed = 718001+i, 718101+i
        orig, sim, state, p_rng, d_rng, final_rng, checks = _native(pa, snr, batch, wave_seed)
        replay = torch.Generator().set_state(d_rng)
        legacy_rx = sim.filter_time_signal(_tx(orig.data_tx, pa), state, orig.noise_var, replay)
        checks["yd"] = _same(_fft(legacy_rx), orig.yd, "native data observation")
        checks["rng_after_original_call"] = _same(final_rng, replay.get_state(), "terminal RNG state")
        # Filtering zeros via the original channel yields exactly the AWGN array at the
        # actual channel addition point. Repeat under each wave-seed-identical payload.
        zero = torch.zeros_like(legacy_rx)
        n_p = sim.filter_time_signal(zero, state, orig.noise_var, torch.Generator().set_state(p_rng))
        n_d = sim.filter_time_signal(zero, state, orig.noise_var, torch.Generator().set_state(d_rng))
        pure_p = sim.filter_time_signal(_tx(orig.pilot_tx, pa), state)
        pure_d = sim.filter_time_signal(_tx(orig.data_tx, pa), state)
        _same(_fft(pure_p+n_p)*orig.pilot_tx.conj(), orig.yp, "native exact pilot AWGN injection")
        _same(pure_d+n_d, legacy_rx, "native exact data AWGN injection")
        maxima = {}
        variants = []
        for iseed in (info_seed, info_seed+1000):
            frame, info = make_frame(pa, snr, batch, wave_seed, iseed)
            words, h = encode_ldpc(info, code)
            f, u, received = _encoded_frame(orig, sim, state, d_rng, pa, iseed)
            checks_now = {
                "systematic": _same(words[:, :64], info, "systematic source bits"),
                "codeword_bits": _same(words, frame.bits.flatten(1), "transmitted codeword"),
                "codeword_symbols": _same(q16(words.reshape_as(frame.bits)), frame.data_tx, "mapped codeword"),
                "pilot_observation": _same(orig.yp, frame.yp, "paired pilot observation"),
                "known_pilot_symbols": _same(orig.pilot_tx, frame.pilot_tx, "paired pilot symbols"),
                "channel": _same(orig.h_true, frame.h_true, "paired static channel"),
                "noise_variance": _same(orig.noise_var, frame.noise_var, "paired noise variance"),
                "received_data": _same(f.yd, frame.yd, "coded public API observation"),
                "info_replay": _same(u, info, "payload RNG replay"),
                "actual_data_noise_injection": _same(
                    sim.filter_time_signal(_tx(frame.data_tx, pa), state)+n_d, received,
                    "exact native time-domain AWGN applied to coded waveform"),
                "exact_fft_after_cp": _same(_fft(received), frame.yd, "received coded FFT"),
            }
            syndrome = (frame.bits.flatten(1) @ h.T) % 2
            _same(syndrome, torch.zeros_like(syndrome), "all parity checks")
            decoded = decode_min_sum((2*words-1).float()*20., h, max_iter=25, alpha=.75)
            checks_now["ideal_llr_decoded_info"] = _same(decoded, info, "known-LLR decoder control")
            for k, v in checks_now.items():
                maxima[k] = max(v, maxima.get(k, 0.))
            variants.append((frame, info))
        (a, u), (b, v) = variants
        changed_words = int((u!=v).any(-1).sum())
        changed_observations = int((a.yd!=b.yd).any(-1).sum())
        if changed_words != batch or changed_observations != batch:
            raise AssertionError("The independent payload did not change the received data in every test frame")
        records.append({"pa": pa, "snr_db": snr, "wave_seed": wave_seed,
                        "info_seeds": [info_seed, info_seed+1000], "native_frames": batch,
                        "coded_frames": 2*batch, "information_bits_checked": 2*batch*64,
                        "encoded_bits_checked": 2*batch*128, "syndrome_checks": 2*batch*64,
                        "nonzero_syndromes": 0, "ideal_llr_decoding_errors": 0,
                        "changed_source_words": changed_words, "changed_received_data_frames": changed_observations,
                        "noise_samples_per_pilot_or_data_symbol_across_batch": n_d.numel(),
                        "native_max_abs_difference": checks, "coded_pair_max_abs_difference": maxima,
                        "pilot_noise_sha256": sha256(n_p.contiguous().numpy().tobytes()).hexdigest(),
                        "data_noise_sha256": sha256(n_d.contiguous().numpy().tobytes()).hexdigest(),
                        "dynamic_matrix_static_expected_none": orig.h_matrix is None})
    return {"profile": "equal4", "normalized_doppler": 0., "n_sc": DEFAULT_N, "cp": DEFAULT_CP,
            "oversample": DEFAULT_OVERSAMPLE, "code": [128,64], "original_frames": sum(r["native_frames"] for r in records),
            "coded_frames": sum(r["coded_frames"] for r in records), "conditions": records}
