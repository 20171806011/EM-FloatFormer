"""Reproduce the frozen development-only P4-B native-code head transfer comparison."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import sys

import numpy as np
import torch

PROTOCOL_SHA256 = "a378b8c62876daee6f2314e6335c6e7adbc60b9c950ca66903c2d893209a5a40"


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def public_forward(model, yp, grid, pilots, noise_var):
    """Observe live locals at return to avoid changing the forward or undoing a rounded floor."""
    fields = ("z_eq", "nv_exp", "h_power_det", "dist_power_det", "sigma_eff2")
    captured = {}
    forward_code = type(model).forward.__code__
    previous = sys.getprofile()
    require(previous is None, "An existing profiler would be displaced.")

    def remember(frame, event, unused):
        if event == "return" and frame.f_code is forward_code:
            captured.update({k: frame.f_locals[k] for k in fields})

    sys.setprofile(remember)
    try:
        result = model(yp, grid, pilots, noise_var)
    finally:
        sys.setprofile(previous)
    denominator = captured["h_power_det"] + 1e-4
    base = captured["nv_exp"] / denominator + captured["dist_power_det"] / denominator
    require(torch.equal(base + 0.035, captured["sigma_eff2"]), "Public variance arithmetic differed")
    return result.llrs, captured["z_eq"], base


def bit_exact(a, b):
    return (a.shape == b.shape and a.dtype == b.dtype
            and torch.equal(a.contiguous().view(torch.uint8), b.contiguous().view(torch.uint8)))


def score(module, payload_logits, code, information, coded_bits):
    slots, blocks, k = information.shape
    require((blocks, k) == (13, 64), "Unexpected native slot payload dimensions")
    # The standard 14 x 32, comb-two layout carries exactly 13 full 128-bit words.
    require(payload_logits[0].numel() == blocks * code.n, "Unregistered payload padding")
    words = payload_logits.reshape(slots, blocks, code.n)
    decoded = module.decode_min_sum(words.reshape(-1, code.n), code.h_matrix, max_iter=25, alpha=0.75)
    information_mismatch = decoded.view_as(information) != information
    blocks_failed = information_mismatch.any(dim=-1)
    before = ((payload_logits > 0) != coded_bits).reshape(slots, -1).sum(dim=1).tolist()
    after = information_mismatch.sum(dim=(1, 2)).tolist()
    result = []
    for i in range(slots):
        mask = ''.join("1" if failed else "0" for failed in blocks_failed[i].tolist())
        result.append({"block_errors": mask.count("1"), "block_failure_mask": mask,
                       "decoded_information_bit_errors": int(after[i]), "predecoder_coded_bit_errors": int(before[i])})
    return result


def measure_batch(module, model, code, slot, arms):
    public, z, base = public_forward(model, slot.yp_sparse, slot.y_grid, slot.pilot_mask, slot.noise_var)
    results = {}
    for arm in arms:
        raw = module.calibrated_16qam_llrs(z, base + arm["variance_floor"], method="exact")
        bound = arm["tanh_bound"]
        logits = (bound * torch.tanh(raw / bound)).to(public.dtype)
        require(torch.isfinite(logits).all().item(), "Nonfinite logits")
        if arm["id"] == "signed":
            require(bit_exact(logits, public), "Default LLRs failed bit-for-bit parity")
        payload = logits[:, slot.data_mask]
        results[arm["id"]] = score(module, payload, code, slot.info_bits, slot.bits)
    native = module._decode_slot_ldpc_blocks(public[:, slot.data_mask], slot.info_bits, code, max_iter=25)
    default = results["signed"]
    require(native == (sum(x["decoded_information_bit_errors"] for x in default), slot.info_bits.numel(),
                       sum(x["block_errors"] for x in default), slot.info_bits.shape[0]*13),
            "Native P4-B default error counts differ")
    return results, public.numel()


def summarize(rows, protocol, snr_index):
    methods = [arm["id"] for arm in protocol["arms"]]
    wave = protocol["waveform"]
    n, blocks = len(rows), wave["codewords_per_slot"]
    require(n == wave["slots_per_snr"], "Missing slots")
    bits = blocks * wave["block_information_length"]
    cbits = blocks * wave["block_code_length"]
    total_blocks = n * blocks
    per_method = {}
    counts = {}
    masks = {}
    for method in methods:
        records = [r["arms"][method] for r in rows]
        masks[method] = np.array([[c == "1" for c in r["block_failure_mask"]] for r in records])
        require(masks[method].shape == (n, blocks), "Incomplete failure masks")
        counts[method] = masks[method].sum(axis=1)
        require(counts[method].tolist() == [r["block_errors"] for r in records], "Mask/count inconsistency")
        ne = int(counts[method].sum())
        be = sum(r["decoded_information_bit_errors"] for r in records)
        pe = sum(r["predecoder_coded_bit_errors"] for r in records)
        per_method[method] = {"block_errors": ne, "total_blocks": total_blocks, "bler": ne/total_blocks,
                              "decoded_information_bit_errors": be, "total_information_bits": n*bits,
                              "decoded_ber": be/(n*bits), "predecoder_coded_bit_errors": pe,
                              "total_coded_bits": n*cbits, "predecoder_ber": pe/(n*cbits)}
    stats = protocol["statistics"]
    rng = np.random.default_rng(stats["bootstrap_base_seed"] + snr_index)
    indices = rng.integers(n, size=(stats["bootstrap_replicates"], n), dtype=np.int64)
    contrasts = []
    for first, second in stats["contrast_pairs"]:
        diff = counts[first]-counts[second]
        resampled = diff[indices].sum(axis=1) / total_blocks
        bounds = np.quantile(resampled, [.025, .975], method="linear").tolist()
        gained = int(np.count_nonzero(masks[first] & ~masks[second]))
        lost = int(np.count_nonzero(~masks[first] & masks[second]))
        require(gained-lost == int(diff.sum()), "Discordant block counts disagree")
        contrasts.append({"first": first, "second": second, "block_error_difference": int(diff.sum()),
                          "bler_difference": float(diff.sum()/total_blocks), "paired_slot_bootstrap_95": bounds,
                          "blocks_wrong_only_first": gained, "blocks_wrong_only_second": lost,
                          "slots_second_has_fewer": int(np.count_nonzero(diff > 0)),
                          "slots_tied": int(np.count_nonzero(diff == 0)),
                          "slots_second_has_more": int(np.count_nonzero(diff < 0))})
    return {"snr_db": wave["snr_db"][snr_index], "slots": n, "arms": per_method, "paired_contrasts": contrasts}


@torch.inference_mode()
def collect(root, protocol, module):
    cfg, wave, draws = protocol["receiver"], protocol["waveform"], protocol["draws"]
    torch.set_num_threads(draws["cpu_threads"])
    torch.use_deterministic_algorithms(True)
    torch.manual_seed(draws["initialization_seed"])
    model = module.EMFloatFormer2D(d_model=cfg["d_model"], n_heads=cfg["n_heads"], depth=cfg["depth"])
    checkpoint = torch.load(root / protocol["checkpoint"], map_location="cpu", weights_only=True)
    model.load_state_dict(checkpoint, strict=True)
    model.eval()
    code = module._get_default_ldpc(128)
    require((code.n, code.k, code.seed) == (128, 64, 2026), "Unexpected LDPC graph")
    simulator = module.SlotSimulator2D(n_symb=wave["n_symb"], n_sc=wave["n_sc"], cp=wave["cp"],
                                       profile=wave["profile"], fd=wave["fd"], cfo=wave["cfo"],
                                       comb=wave["comb"], oversample=wave["oversample"])
    records, conditions = [], []
    checked = 0
    for ci, snr in enumerate(wave["snr_db"]):
        current = []
        for batch in range(wave["slots_per_snr"] // wave["slots_per_batch"]):
            seed = draws["waveform_seed_base"] + draws["waveform_seed_stride_per_snr"]*ci + batch
            slot = simulator.generate_slot(batch_size=wave["slots_per_batch"], snr_db=float(snr),
                                           pa_condition=wave["pa_condition"], coded=True, ldpc=code,
                                           generator=torch.Generator().manual_seed(seed))
            synchronized = module._synchronize_slot(slot)
            arm_rows, checked_batch = measure_batch(module, model, code, synchronized, protocol["arms"])
            checked += checked_batch
            for i in range(wave["slots_per_batch"]):
                current.append({"snr_db": snr, "slot_index": len(current), "batch_seed": seed, "within_batch": i,
                                "total_blocks": 13, "total_information_bits": 832, "total_coded_bits": 1664,
                                "arms": {name: values[i] for name, values in arm_rows.items()}})
        records.extend(current)
        conditions.append(summarize(current, protocol, ci))
        print(f"{snr} dB: {len(current)} paired slots completed.", file=sys.stderr, flush=True)
    require(all(bit_exact(tensor, checkpoint[key]) for key, tensor in model.state_dict().items()),
            "Receiver state was modified")
    require(checked == len(records) * 14 * 32 * 4, "Public parity coverage incomplete")
    return {"conditions": conditions, "slot_records": records,
            "verification": {"public_default_full_grid_llr_elements_byte_equal": checked,
                             "public_default_native_decoder_batches_equal": len(records)//wave["slots_per_batch"],
                             "model_state_byte_equal_to_loaded_checkpoint": True,
                             "ldpc_h_matrix_uint8_rowmajor_sha256": hashlib.sha256(
                                 code.h_matrix.to(torch.uint8).contiguous().numpy().tobytes()).hexdigest()}}


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--root", type=Path, required=True, help="EM-FloatFormer repository root")
    cli.add_argument("--output", type=Path, required=True, help="New output JSON path outside the repository")
    args = cli.parse_args()
    root, out = args.root.resolve(), args.output.resolve()
    require(not out.is_relative_to(root), "Output must be outside the study repository")
    script = Path(__file__).resolve()
    protocol_path = script.with_name("transfer_protocol.json")
    require(digest(protocol_path) == PROTOCOL_SHA256, "Transfer protocol hash mismatch")
    protocol = json.loads(protocol_path.read_bytes())
    for path, expected in protocol["dependencies_sha256"].items():
        require(digest(root / path) == expected, f"Frozen dependency changed: {path}")
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(root))
    from p4 import slot_2d
    require(Path(slot_2d.__file__).resolve() == root/"p4/slot_2d.py", "Unexpected imported module")
    data = collect(root, protocol, slot_2d)
    report = {"study": protocol["study"], "protocol_sha256": PROTOCOL_SHA256, "script_sha256": digest(script),
              "dependencies_sha256": protocol["dependencies_sha256"], "checkpoint_sha256": digest(root / protocol["checkpoint"]),
              "runtime": {"python": platform.python_version(), "torch": str(torch.__version__),
                          "numpy": np.__version__, "device": "cpu", "cpu_threads": torch.get_num_threads()},
              **data}
    serialized = (json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf8")
    if out.exists():
        require(out.read_bytes() == serialized, "Existing result differs; refusing replacement")
    else:
        with out.open("xb") as fp:
            fp.write(serialized)
    print(f"{out}  sha256={hashlib.sha256(serialized).hexdigest()}")


if __name__ == "__main__":
    main()

