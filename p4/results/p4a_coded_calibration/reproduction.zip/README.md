# P4-A coded LLR calibration supplement

Run from the EM-FloatFormer project directory with the study's PyTorch CPU environment. Expand the archive into a separate temporary directory. All commands read the original project implementation and write any new output in the expanded study directory.

```powershell
$project = (Get-Location).Path
$study = Join-Path $env:TEMP ('emff-readouts-' + [guid]::NewGuid())
Expand-Archive -LiteralPath (Join-Path $project 'p4/results/p4a_coded_calibration/reproduction.zip') -DestinationPath $study
python -B "$study/run.py" --root "$project" --output "$study/output" --replay
python -B "$study/analyze.py" "$study/output/raw.json" --output "$study/output/summary-recomputed.json"
python -B "$study/transfer.py" --root "$project" --output "$study/transfer.json"
```

The first command after extraction reloads the eight saved one-dimensional fits, regenerates real coded frames and checks every readout count and failed-frame mask. For a fresh training run, omit `--replay` and give a new output directory. The comparison uses identical weights for all readouts of a given model and supplies only the received observations and noise variance to the receiver. The two-dimensional transfer study uses the previously trained development checkpoint identified by its SHA-256 in transfer_protocol.json. Both protocols specify independent development data. The sealed ten-seed study has its own protocol and error-rate comparisons.
