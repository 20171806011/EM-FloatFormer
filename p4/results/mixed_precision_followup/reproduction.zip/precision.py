"""A post-study two-sample, one-dimensional precision diagnostic on the signed P4-C weights."""
import argparse
from collections import Counter
from contextlib import contextmanager, ExitStack
import hashlib
import json
from pathlib import Path
import platform
import sys
from unittest.mock import patch

import torch
from torch.nn import functional as F
from torch.utils._python_dispatch import TorchDispatchMode

PIN = "44b5364721b33b2541b508a1d7eb3df51e26610e57b787159bf8edd38a232292"


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def weight_fingerprint(model):
    h = hashlib.sha256()
    for k, v in sorted(model.state_dict().items()):
        x = v.detach().contiguous().cpu()
        h.update((json.dumps([k, str(x.dtype), list(x.shape)], indent=2) + "\n").encode())
        h.update(x.numpy().tobytes())
    return h.hexdigest()


class KernelTrace(TorchDispatchMode):
    """Record dispatched GEMM operator dtypes and counts, with optional per-projection tags."""
    def __init__(self):
        super().__init__()
        self.counts = Counter()
        self.tag = "unlabelled"

    @contextmanager
    def named(self, name):
        prev, self.tag = self.tag, name
        try:
            yield
        finally:
            self.tag = prev

    def __torch_dispatch__(self, func, types, args=(), kwargs=None):
        result = func(*args, **(kwargs or {}))
        if func in (torch.ops.aten.mm.default, torch.ops.aten.bmm.default, torch.ops.aten.addmm.default):
            a, b = args[1:3] if func == torch.ops.aten.addmm.default else args[:2]
            key = (self.tag, str(func), str(a.dtype), str(b.dtype), str(result.dtype))
            self.counts[key] += 1
        return result

    def dump(self):
        return [{"module": k[0], "operator": k[1], "lhs": k[2], "rhs": k[3], "out": k[4], "calls": v}
                for k, v in sorted(self.counts.items())]


def anchor32(pilot):
    require(pilot.dtype == torch.complex64, "Expected FP32 real/imag observations")
    m = pilot.abs().amax(-1, keepdim=True)
    safe = torch.where(m > 0, m, torch.ones_like(m))
    z = pilot/safe
    power = (z.real.square() + z.imag.square()).mean(-1, keepdim=True)
    anchor = torch.where(m > 0, (m*power.sqrt()).clamp_min(1e-38), torch.full_like(m, 1e-38))
    require(anchor.dtype == torch.float32, "Gauge anchor promoted")
    return anchor


def rms32(module, z):
    require(z.dtype == torch.complex64, "RMS normalizer received a promoted state")
    m = z.abs().amax(dim=-1, keepdim=True)
    active = m > 1e-38
    safe = torch.where(active, m, torch.ones_like(m))
    scaled = z/safe
    energy = (scaled.real.square() + scaled.imag.square()).mean(-1, keepdim=True)
    divisor = (energy + module.eps**2).sqrt()
    return scaled * (module.gamma.float() / torch.where(active, divisor, torch.ones_like(divisor)))


def bf16_projection(module, z):
    xr, xi = z.real.bfloat16(), z.imag.bfloat16()
    wr, wi = module.weight_r.bfloat16(), module.weight_i.bfloat16()
    rr = F.linear(xr, wr).float() - F.linear(xi, wi).float()
    ii = F.linear(xr, wi).float() + F.linear(xi, wr).float()
    if module.bias_r is not None:
        rr, ii = rr + module.bias_r.float(), ii + module.bias_i.float()
    return torch.complex(rr, ii)


@contextmanager
def split_engine(model, signed, trace):
    with ExitStack() as stack:
        for name, module in model.named_modules():
            if isinstance(module, signed.ComplexLinear):
                def run(z, this=module, tag=name, orig=module.forward):
                    with trace.named(tag):
                        if tag.startswith("blocks."):
                            return bf16_projection(this, z)
                        require(z.dtype == torch.complex64, "Non-block projection received a promoted tensor")
                        return orig(z)
                stack.enter_context(patch.object(module, "forward", side_effect=run))
            elif isinstance(module, signed.ComplexRMSNorm):
                stack.enter_context(patch.object(module, "forward",
                                                 side_effect=lambda z, this=module: rms32(this, z)))
        yield


def split_forward(model, signed, inputs):
    yp, yd, nv = inputs
    require(yp.dtype == yd.dtype == torch.complex64 and nv.dtype == torch.float32, "Wrong input boundary")
    anchor = anchor32(yp)
    pilot, data, noise = yp/anchor, yd/anchor, nv.reshape(-1, 1)/anchor.square()
    pt, dt = model.embed.embed_pilot(pilot), model.embed.embed_data(data)
    for block in model.blocks:
        pt, dt = block(pt, dt)
    pt = pt + .1*model.norm_p(pt)
    dt = dt + .1*model.norm_d(dt)
    h = pilot + model.head_h(pt).squeeze(-1)
    dist = model.head_dist(dt).squeeze(-1)
    eff = model.gamma_eff(h.unsqueeze(-1)).squeeze(-1)
    power = eff.real.square() + eff.imag.square()
    denom = power + 1e-4
    eq = (data * eff.conj())/denom - (dist * eff.conj())/denom
    var = noise/denom + (dist.real.square() + dist.imag.square())/denom + .035
    raw = signed.calibrated_16qam_llrs(eq, var, method="exact")
    require(pt.dtype == dt.dtype == eq.dtype == torch.complex64 and var.dtype == raw.dtype == torch.float32,
            "Unexpected hybrid state or physical readout precision")
    return signed.FloatFormerOutput(h*anchor, 20*torch.tanh(raw/20), dist*anchor)


def compare(ref, pred):
    delta = (pred-ref).abs()
    return {"bits": ref.numel(), "hard_bit_flips": int(((pred>0) != (ref>0)).sum()),
            "max_abs_llr_difference": float(delta.max()), "mean_abs_llr_difference": float(delta.mean()),
            "max_lt_0p15": bool(float(delta.max())<.15)}


def run(root, protocol):
    from p4 import ablation_probing as probe, em_floatformer as signed, factorial
    a = json.loads((root/"p4/results/p4c_mechanism_probes.json").read_bytes())
    archive_factorial = json.loads((root/"p4/results/p4c_factorial.json").read_bytes())
    torch.set_num_threads(a["threads"])
    require(a["threads"] == 1 and a["training_seed"] == 71301 and a["pytorch"] == str(torch.__version__),
            "Historical CPU runtime mismatch")
    model = probe.probe_model()
    model.eval()
    state_hash = weight_fingerprint(model)
    archived = {r["scale"]:r for r in a["storage_and_projection_precision"] if r["dtype"]=="torch.bfloat16"}
    rows = []
    old_trace, split_trace = KernelTrace(), KernelTrace()
    typed = {n for n, m in model.named_modules() if isinstance(m, signed.ComplexLinear)}
    with torch.no_grad():
        old_eval_seed = 71301 + factorial.PROTOCOL["evaluation"]["data_seed_offset"]
        factorial_frame = factorial.observation(96, seed=old_eval_seed, snr_db=10.)
        require(factorial.evaluate_arm(model, factorial_frame, 71301, 1) == archive_factorial["rows"][0],
                "Published arm identity or integer counts differ")
        require(probe.attention_probe(model, 73512) == a["trained_attention"],
                "Published trained attention does not reproduce")
        for seed in protocol["conditions"]["observation_seeds"]:
            frame = factorial.observation(32, seed=seed, snr_db=15.)
            group = []
            for scale in protocol["conditions"]["gains"]:
                inputs = factorial.scaled_inputs(frame, scale)
                ref = model(*inputs)
                anchor = signed.compute_gauge_anchor(inputs[0]).float()
                normalized = (inputs[0]/anchor, inputs[1]/anchor, inputs[2].reshape(-1,1)/anchor.square())
                bf_in = tuple(probe.quantize_storage(x, torch.bfloat16) for x in normalized)
                # Invoke the original audit's signed hook path and measure its native GEMMs.
                with old_trace, probe.reduced_projection_gemms(model, torch.bfloat16):
                    old = model(*bf_in)
                with split_trace, split_engine(model, signed, split_trace):
                    split = split_forward(model, signed, inputs)
                require(all(torch.isfinite(t).all().item() for output in (ref,old,split) for t in output),
                        "Nonfinite receiver output")
                metrics = {name:compare(ref.llrs, result.llrs) for name,result in
                           (("original_all_bf16_projections_and_storage",old),("mixed_blocks_only",split))}
                if seed == 73510:
                    legacy = archived[scale]
                    calc = metrics["original_all_bf16_projections_and_storage"]
                    require(calc["max_abs_llr_difference"] == legacy["normalized_gemm_max_logit_error"]
                            and calc["mean_abs_llr_difference"] == legacy["normalized_gemm_mean_logit_error"]
                            and calc["bits"] == legacy["bits"] and calc["hard_bit_flips"] == legacy["normalized_gemm_flip_count"]
                            and legacy["normalized_gemm_nonfinite"] == 0, f"Signed original values did not reproduce at {scale}")
                group.append((scale,metrics,{"reference":ref.llrs,"original_all_bf16_projections_and_storage":old.llrs,
                                             "mixed_blocks_only":split.llrs}))
            unit = next(outputs for gain,_,outputs in group if gain==1)
            for gain,metrics,outputs in group:
                rows.append({"frame_seed":seed,"frames":32,"snr_db":15.0,"gain":gain,
                             "compared_to_signed_reference":metrics, "nonfinite_output_elements":0,
                             "within_engine_vs_unit_gain":{k:compare(unit[k],v) for k,v in outputs.items()}})
    require(weight_fingerprint(model)==state_hash,"Underlying trained state changed")
    traces = {"original":old_trace.dump(),"mixed_blocks_only":split_trace.dump()}
    for name in sorted(typed):
        expected = "torch.bfloat16" if name.startswith("blocks.") else "torch.float32"
        entries=[line for line in traces["mixed_blocks_only"] if line["module"]==name]
        require(entries and sum(line["calls"] for line in entries)==40 and
                all(line["lhs"]==line["rhs"]==line["out"]==expected for line in entries),
                f"Unexpected dispatched precision or count for {name}")
    legacy_bf = sum(line["calls"] for line in traces["original"]
                    if line["lhs"] == line["rhs"] == line["out"] == "torch.bfloat16")
    require(legacy_bf==40*len(typed),"Original BF16 GEMM coverage mismatch")
    return {"weights_sha256":state_hash,"weight_provenance":"Deterministic development reconstruction; signed archived checkpoint hash unavailable.",
            "archived_parity":{"matched_factorial_arm_row_exact":True,"trained_attention_all_entries_exact":True,
                               "original_bf16_quantized_input_and_gemm_5_rows_exact":True},
            "per_frame_group_and_gain":rows,"gemm_execution":{"source":"TorchDispatchMode logs actual aten CPU operators; dtype is operand and output dtype, not a hardware accumulator claim.",
            "trace_covers_forward_passes_per_engine":10,"original_bf16_real_gemms":legacy_bf,
            "split_block_projection_names":sorted(n for n in typed if n.startswith("blocks.")),
            "split_fp32_projection_names":sorted(n for n in typed if not n.startswith("blocks.")),
            "operator_counts":traces}}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    root,out=args.root.resolve(),args.output.resolve()
    require(not out.is_relative_to(root),"Output must be outside the study repository")
    script=Path(__file__).resolve()
    protocol_path=script.with_name("precision_protocol.json")
    require(sha(protocol_path)==PIN,"Frozen diagnostic protocol mismatch")
    protocol=json.loads(protocol_path.read_bytes())
    for name,expected in protocol["source_sha256"].items():
        require(sha(root/name)==expected,f"Source changed: {name}")
    sys.dont_write_bytecode=True
    sys.path.insert(0,str(root))
    data=run(root,protocol)
    outdata={"scope":protocol["scope"],"protocol_sha256":PIN,"script_sha256":sha(script),
             "source_sha256":protocol["source_sha256"],"runtime":{"python":platform.python_version(),
             "torch":str(torch.__version__),"threads":torch.get_num_threads(),"device":"cpu"},**data}
    serialized=(json.dumps(outdata,indent=2,ensure_ascii=False,allow_nan=False)+"\n").encode("utf-8")
    if out.exists():
        require(out.read_bytes()==serialized,"Existing output is different")
    else:
        with out.open("xb") as file: file.write(serialized)
    print(f"{out}  SHA256 {hashlib.sha256(serialized).hexdigest()}")


if __name__=="__main__":
    main()

