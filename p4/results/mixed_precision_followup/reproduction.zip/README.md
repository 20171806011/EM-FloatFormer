# Development mixed-precision checks for P4

Both scripts run against the original signed sources and check their SHA-256 inputs. Extract this archive separately from the repository. Use the recorded Python/PyTorch CPU environment. From the extracted directory, give the project root and distinct output paths.

    python -B precision.py --root <project> --output one_dimensional_replay.json
    python -B mixed_audit_v2.py --root <project> --evaluate --output two_dimensional_replay.json

precision.json and results.json are the observed one-dimensional and two-dimensional results. The one-dimensional study uses the published wide-precision receiver as its reference. The two-dimensional study uses packed FP32 projections as its reference. Both count real BF16 operations and preserve the original full-BF16 comparator. No throughput estimate for the block-only mixed variant was made. The original two-dimensional counting hook did not recognize aten.linear dispatch. The second protocol adds this event, with the original arms, data, and thresholds preserved.
