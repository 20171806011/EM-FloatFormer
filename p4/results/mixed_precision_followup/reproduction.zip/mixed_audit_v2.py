"""Prospective selective BF16 projection study for a frozen 2D receiver. No training or timing."""
import argparse
from collections import Counter
from contextlib import ExitStack
from hashlib import sha256
import json
from pathlib import Path
import sys

import torch
from torch.utils._python_dispatch import TorchDispatchMode


BASE = Path(__file__).resolve().parent
SEAL = BASE / "protocol_v2.json"
ARMS = ("fp32", "all_bf16", "blocks_bf16")
ROOT_FILES = ("p4/stage3_precision.py", "p4/em_floatformer.py", "p4/next_neural.py",
              "p4/slot_2d.py", "p4/simulator.py", "p4/pilot_prior_probe.py", "p4/classical_baselines.py",
              "p4/results/next_neural_tap_phase_no_channel_73161.pt", "p4/results/stage3_precision.json")


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def spec(root):
    return {"instrumentation_amendment":"The first attempt recognized only lowered mm/addmm/bmm. This PyTorch exposes the direct aten.linear operator under inference mode. Only the operator instrumentation was extended; no output metrics had been emitted. Arms, data and all criteria are unchanged.", "original_protocol_sha256":digest(BASE/"protocol.json"), "aim":"One preselected mixed allocation, with all-FP32 and all-BF16 packed projection controls.",
            "scope":"Each precision label applies to real packed GEMMs implementing ComplexLinear; gauge, FFT, Hermitian scores, other residual operations and final LLR formulas retain their original arithmetic.",
            "arms":dict(fp32="All ComplexLinear GEMMs FP32", all_bf16="All ComplexLinear GEMMs BF16",
                        blocks_bf16="Every ComplexLinear below blocks.* in BF16, all other ComplexLinear in FP32"),
            "snr_db":[0,5,10,15,20], "slots_per_snr":20, "batch":4,
            "seed_bases":{"archived":934000,"independent":1934000},
            "seed_formula":"base + 100*SNR_index + within_SNR_slot_offset",
            "checkpoint":"first prior frozen TapPhaseNoChannel training replicate 73161",
            "comparisons":"All versus FP32 on the same payload data REs, count >0 sign changes, max absolute LLR error, nonfinite on all public outputs. Record actual GEMM operand/result dtypes per arm/call.",
            "predeclared_criteria":{"max_abs_logit_error_strictly_below":.15,"decision_flip_rate_strictly_below":.0005,"nonfinite_count":0},
            "threads":2,"torch":str(torch.__version__),"script_sha256":digest(Path(__file__)),
            "project_sources":{f:digest(root/f) for f in ROOT_FILES}}


class ProjectionTrace(TorchDispatchMode):
    """Count the actual ATen GEMM under each original packed projection's forward."""
    def __init__(self):
        super().__init__()
        self.active = None
        self.calls = Counter()
        self.kernels = Counter()

    def hooks(self, name):
        def before(module, inputs):
            assert self.active is None
            self.active = (name, module.matrix.dtype)
            self.calls[name] += 1
        def after(module, inputs, out):
            assert self.active[0] == name
            self.active = None
        return before, after

    def __torch_dispatch__(self, func, types, args=(), kwargs=None):
        out = func(*args, **(kwargs or {}))
        if self.active and func in (torch.ops.aten.linear.default,torch.ops.aten.mm.default,torch.ops.aten.addmm.default,torch.ops.aten.bmm.default):
            name, configured = self.active
            operands = [x.dtype for x in args if isinstance(x, torch.Tensor)]
            if not operands or any(dtype != configured for dtype in operands) or out.dtype != configured:
                raise AssertionError(f"{name} GEMM dtype differs from assigned {configured}: {operands}, {out.dtype}")
            self.kernels[name,str(configured),str(func)] += 1
        return out

    def report(self, names):
        by_name = Counter()
        by_dtype = Counter()
        for (name,dtype,_), n in self.kernels.items():
            by_name[name] += n
            by_dtype[dtype] += n
        assert set(self.calls) == set(names) and self.calls == by_name
        return {"module_counts_by_dtype":dict(Counter(names.values())),
                "observed_gemm_calls_by_dtype":dict(by_dtype),
                "modules":{name:{"dtype":dtype,"calls":self.calls[name]} for name,dtype in names.items()},
                "observed_kernel_types":sorted({op for _,_,op in self.kernels})}


@torch.inference_mode()
def evaluate(root, settings):
    from p4.stage3_precision import PackedProjection, sample, engines
    # The two control engines are the actual original constructors. The selective arm
    # uses the original BF16 modules inside blocks and fresh original FP32 modules elsewhere.
    from p4.next_neural import TapPhaseNoChannel
    from p4.em_floatformer import ComplexLinear
    control = engines()
    mixed = TapPhaseNoChannel().eval()
    checkpoint = root/"p4/results/next_neural_tap_phase_no_channel_73161.pt"
    mixed.load_state_dict(torch.load(checkpoint, map_location="cpu", weights_only=True)["weights"])
    for name, module in list(mixed.named_modules()):
        if isinstance(module, ComplexLinear):
            precision = torch.bfloat16 if name.startswith("blocks.") else torch.float32
            mixed.set_submodule(name, PackedProjection(module, precision))
    models = {"fp32":control["torch.float32"], "all_bf16":control["torch.bfloat16"], "blocks_bf16":mixed}
    names = {arm:{name:str(m.matrix.dtype) for name,m in net.named_modules() if isinstance(m,PackedProjection)}
             for arm,net in models.items()}
    assert names["fp32"].keys() == names["all_bf16"].keys() == names["blocks_bf16"].keys()
    traces = {arm:ProjectionTrace() for arm in ARMS}
    rows = []
    with ExitStack() as stack:
        for arm,net in models.items():
            for name,m in net.named_modules():
                if isinstance(m,PackedProjection):
                    pre,post=traces[arm].hooks(name)
                    stack.enter_context(m.register_forward_pre_hook(pre))
                    stack.enter_context(m.register_forward_hook(post))
        for dataset,base in settings["seed_bases"].items():
            for si,snr in enumerate(settings["snr_db"]):
                stats = {arm:{"flips":0,"bits":0,"nonfinite":0,"max_logit_error":0.} for arm in ARMS}
                for offset in range(0,settings["slots_per_snr"],settings["batch"]):
                    inp=sample(settings["batch"],base+100*si+offset,snr)
                    output={}
                    for arm in ARMS:
                        with traces[arm]:
                            pred=models[arm](*inp)
                        stats[arm]["nonfinite"] += sum(int((~torch.isfinite(x)).sum()) for x in pred)
                        output[arm]=pred.llrs[:,~inp[2]]
                    ref=output["fp32"]
                    for arm,pred in output.items():
                        row=stats[arm]
                        row["flips"]+=int(((pred>0)!=(ref>0)).sum())
                        row["bits"]+=ref.numel()
                        row["max_logit_error"]=max(row["max_logit_error"],float((pred-ref).abs().max()))
                for arm,s in stats.items():
                    assert s["bits"] == 20*416*4
                    rows.append(dict(dataset=dataset,snr_db=snr,arm=arm,slots=20,**s,flip_rate=s["flips"]/s["bits"]))
    original=json.loads((root/"p4/results/stage3_precision.json").read_bytes())["mixed"]["rows"]
    exact=[]
    for r in rows:
        if r["dataset"]=="archived" and r["arm"] in ("fp32","all_bf16"):
            dtype={"fp32":"torch.float32","all_bf16":"torch.bfloat16"}[r["arm"]]
            paired, = [s for s in original if s["dtype"]==dtype and s["snr_db"]==r["snr_db"]]
            exact.append(all(r[k]==paired[k] for k in ("slots","flips","bits","max_logit_error","nonfinite")))
    assert len(exact)==10 and all(exact)
    pooled=[]
    for dataset in settings["seed_bases"]:
        for arm in ARMS:
            subset=[r for r in rows if r["dataset"]==dataset and r["arm"]==arm]
            flips=sum(r["flips"] for r in subset)
            bits=sum(r["bits"] for r in subset)
            nonfinite=sum(r["nonfinite"] for r in subset)
            largest=max(r["max_logit_error"] for r in subset)
            pooled.append(dict(dataset=dataset,arm=arm,slots=100,bits=bits,flips=flips,flip_rate=flips/bits,
                               max_logit_error=largest,nonfinite=nonfinite,
                               meets_all_numerical_criteria=(largest<.15 and flips/bits<.0005 and nonfinite==0)))
    return {"protocol_sha256":digest(SEAL),"rows":rows,"dataset_totals":pooled,
            "archived_control_rows_reproduced_exactly":sum(exact),
            "projection_gemm_evidence":{arm:traces[arm].report(names[arm]) for arm in ARMS},
            "timing":"No timing or native acceleration analysis in this supplement."}


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",required=True,type=Path)
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--seal",action="store_true")
    group.add_argument("--evaluate",action="store_true")
    parser.add_argument("--output",type=Path,default=BASE/"results.json")
    opts=parser.parse_args()
    root=opts.root.resolve()
    sys.path.insert(0,str(root))
    config=spec(root)
    if opts.seal:
        with SEAL.open("x",encoding="utf-8") as stream:
            json.dump(config,stream,indent=2)
    else:
        if config!=json.loads(SEAL.read_bytes()):
            raise RuntimeError("Code, model, runtime, source or evaluation design differs from the sealed study")
        if opts.output.resolve()==SEAL or opts.output.resolve()==Path(__file__).resolve():
            raise ValueError("Results must be separate from protocol and source")
        torch.set_num_threads(config["threads"])
        result=evaluate(root,config)
        with opts.output.open("w",encoding="utf-8") as stream:
            json.dump(result,stream,indent=2,allow_nan=False)
        for row in result["dataset_totals"]:
            print(row,flush=True)
